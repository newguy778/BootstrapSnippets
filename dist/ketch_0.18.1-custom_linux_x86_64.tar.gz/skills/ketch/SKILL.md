---
name: ketch
description: "Research skill for ketch, a stateless CLI for web search, OSS code search, library docs, page scraping, and site crawling (optional MCP server). Use when a question needs live sources — research X, what people say about Y, docs or real examples for Z, scrape or crawl a site — or when installing or configuring ketch backends. Not for local codebase search, private repos, or pages behind auth."
---

# ketch

Route each live-source question to one surface. Prefer the operator's transport: the `ketch` MCP tools if present (`ketch:search`; Claude Code `mcp__ketch__search`), otherwise the CLI (`ketch <cmd>`, `--json`). Operator actions — `config`, `browser install`, `cache`, `doctor`, background crawls — are CLI-only and mutate only after the operator confirms the exact command.

## Routing

| Need | Surface |
|---|---|
| Web pages, news, opinions | `search` |
| How real projects call an API | `code` |
| A library's own documentation | `docs` |
| The content of a URL | `scrape` |
| Many pages from one site | `crawl` |
| Something already found | `tag show` |

## Budgets

Bound every fetch; an unguarded page can cost ~25k tokens.

- Unknown page: `--max-chars 4000–8000 --trim`.
- Lists: `--limit` 5 (`search`), 3 (`code`); `--minimal` halves output.
- Docs: `--tokens` 4000.
- MCP `crawl`: `max_pages` 30 (cap 100, 3-minute wall clock).

## Errors — exit code / MCP prefix

- `2 [validation]` — bad input; fix it, never retry unchanged.
- `3 [not_found]` — nothing matched; change the query or selector.
- `4 [upstream]` — network or backend. Rotate once to another provider from `available_backends` (`ketch config` lists them); `auto` already tried every usable provider, so retry once then report.
- `5 [precondition]` — config missing; see [reference.md](reference.md#setup).
- `6 [cancelled]` — rerun with smaller scope.

ddg rate-limits readily; grepapp intermittently 504s.

## Gotchas

- Batch `scrape` succeeds with per-URL failures in `results[].error` — check every entry.
- `docs --resolve` never returns empty: vet the match name before fetching by `--library`.
- A bare-domain scrape probes `/llms.txt` first — check the returned `title`; `--no-llms-txt` opts out.
- JS-shell pages fall back to the configured browser; without one, `--force-browser` is `[precondition]`.
- A running MCP server holds the page-cache lock, so concurrent CLI fetches run uncached.

[reference.md](reference.md) — flags, backends/config, setup, and the deep-research flow.
