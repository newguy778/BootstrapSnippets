# ketch reference

`ketch --help` and `ketch config` are ground truth; treat this file as drift-prone.

## Transport

MCP tools are `ketch:search|code|docs|scrape|crawl|tag` (Claude Code `mcp__ketch__*`). Options map 1:1 with the flags (`--max-chars` → `max_chars`), except `--select`→`selector`, `--regex`→`regexp`, `--force-browser`→`force_browser`, `--no-llms-txt`→`no_llms_txt`, `--no-cache`→`no_cache`; `multi` and `random` are arrays. CLI-only: `--minimal`, `--json`, `--background`, `crawl status|stop`, and verb-style `tag add|show|list|remove`.

## search

- `auto` (the default) walks `search_priority` when configured — an ordered allowlist — otherwise descriptor ranks. Unusable providers are skipped; failures appear as `warn:` stderr lines or MCP `errors`.
- Backends: brave (keyed), ddg, firecrawl, keenable, parallel. `ketch config` lists `available_backends`.
- `--scrape` fetches every hit; budget it like a scrape.
- `--multi` / `--random`: bare or `=all` = every usable backend; `=brave,ddg` = a set (CLI needs `=`). Mutually exclusive with `backend`.
- `--minimal`: one result per line, tab-separated.

## code

- Backends: grepapp (default, keyless), sourcegraph (keyless), github (`gh auth login`, `$GITHUB_TOKEN`, or `github_token`).
- `--repo owner/name` is exact on every backend; prefer it to a typed `repo:` (grepapp matches qualifiers as literal text and warns). A missing repo is `[not_found]` on sourcegraph/github and a warning on grepapp.
- `--regex` works on grepapp and sourcegraph only.

## docs

- context7 only, needs `context7_api_key`; `local` is planned and returns `[precondition]`.
- Two-step: `--resolve "name"` → vet the match name → `--library /org/repo`. Resolve never returns empty.
- `--tokens` default 4000.

## scrape

- Inputs: one URL, positional list, JSON array, file of URLs, or stdin pipe. Batches run concurrently and report per-URL failures in `results[].error` inside a successful call.
- `--select` skips content selection (no match → `[not_found]`); `--raw` returns HTML; `--trim` strips markdown syntax; `--no-cache` bypasses the page cache (bbolt, 72h).
- A bare-domain URL probes `/llms.txt` first — the returned `title` reveals the swap; `--no-llms-txt` opts out.
- `curl -L <url> | ketch extract` converts HTML with no fetch, cache, or browser (CLI-only).

## crawl

- Same-host BFS; `--sitemap` treats the seed as a sitemap. CLI: `--depth` 3, `--allow`/`--deny`, `--concurrency` 8, and `--background`/`status`/`stop`.
- MCP: synchronous, `max_pages` 30 (cap 100) and a 3-minute wall clock; partial results carry `stopped: "max_pages"|"timeout"`.
- SIGINT on the CLI exits 0 with the pages already streamed.

## tag

- No network. `--tag` on any surface; `ketch tag add|show|list|remove`. `show` returns the 50 newest by default, `0` = all.
- Entries outlive cached bodies: `cached: false` means no fresh body was confirmed, not a dead link.
- Storage is `tags.db` in the config dir; `KETCH_TAGS_PATH` overrides.

## Configuration

- File: `~/.config/ketch/config.json`. Precedence: flag > `KETCH_*` env > file > default. `ketch config` is the discovery call (`available_backends`, `*_key_set` booleans, `env_overrides`).
- Search chain: `search_priority` (`["ddg","firecrawl"]` or a comma list; `[]` = descriptor ranks; `KETCH_SEARCH_PRIORITY`); unknown ids fail at set time.
- Keys: `brave_api_key`/`_keys`, `firecrawl_api_key`/`_url`, `keenable_api_key`, `context7_api_key`, `github_token`; plus `backend`, `code_backend`, `docs_backend`, `limit`, `browser`, `cache_ttl`, `cookie_file`, `user_agent`, `extract_mode`, `mcp_tools`, `url_rewrites`, `spa_markers`.
- Isolate labs with `KETCH_CONFIG`, `KETCH_TAGS_PATH`, and `XDG_CACHE_HOME`.

## Setup

Read, probe, propose, confirm.

1. Read `ketch config`; probe `ketch doctor --json` (exit 0 healthy, 5 broken). On older builds, probe by hand: `ketch search "test" -l 1`, `ketch code "test" -l 1`, `ketch docs --resolve "react" -l 1`, `ketch browser status`. Exit 4 is reachability, not configuration.
2. Search works with no key via `auto`; adding `brave_api_key` puts brave first, `firecrawl_api_key`/`keenable_api_key` lift hosted caps, `firecrawl_url` points at a self-hosted instance. Reorder with `search_priority`.
3. Code: grepapp and sourcegraph need nothing; github needs auth. Docs: `context7_api_key`. Browser: `ketch config set browser <path>` or `ketch browser install`.
4. Propose the exact commands, wait for confirmation, then re-probe and report.

## Deep research flow

Search fan-out → fetch the best sources within budget → corroborate load-bearing claims → cited synthesis.

1. Plan: 1–3 queries with distinct angles; state caps (3–5 pages, `max_chars` 4000–8000 + `trim`, 8 calls).
2. Search: limit 5; on `[upstream]` rotate once and note it.
3. Select: 3–5 primary sources (official docs, repo/issues, papers), hosts deduped.
4. Fetch: one batch `scrape`; check every `results[].error` and name dropped sources.
5. Corroborate: `docs` for library APIs, `code` for "people do X in practice" — only for load-bearing claims.
6. Synthesize: answer first, every claim citing its URL; state conflicts; list used, dropped, unverified.

8 calls per run unless the user asks for more; stop early when two independent sources agree.
