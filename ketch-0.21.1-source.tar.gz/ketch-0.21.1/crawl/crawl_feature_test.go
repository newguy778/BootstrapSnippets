package crawl

import (
	"context"
	"encoding/xml"
	"errors"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/1broseidon/ketch/cache"
	"github.com/1broseidon/ketch/config"
	"github.com/1broseidon/ketch/scrape"
	"github.com/1broseidon/ketch/urlrewrite"
)

func newCrawlTestCache(t *testing.T) *cache.Cache {
	t.Helper()
	store, err := cache.NewBBoltStore(filepath.Join(t.TempDir(), "cache.db"))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = store.Close() })
	return cache.NewWithStore(store, time.Hour)
}

func TestCrawlWarmCacheTraversesSavedNavigationLinks(t *testing.T) {
	var requests atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		requests.Add(1)
		w.Header().Set("Content-Type", "text/html")
		if r.URL.Path == "/child" {
			_, _ = w.Write([]byte(`<html><body><main>child</main></body></html>`))
			return
		}
		_, _ = w.Write([]byte(`<html><body><main>root</main></body><nav><a href="/child">Child</a></nav></html>`))
	}))
	t.Cleanup(server.Close)
	pc := newCrawlTestCache(t)
	seed := server.URL + "/"
	for run := 0; run < 2; run++ {
		var results []Result
		if err := Crawl(t.Context(), seed, scrape.New(), Options{Depth: 1, Concurrency: 1}, pc, false, func(r Result) {
			results = append(results, r)
		}); err != nil {
			t.Fatal(err)
		}
		seen := make(map[string]Result, len(results))
		for _, result := range results {
			seen[result.URL] = result
		}
		childURL := server.URL + "/child"
		if len(seen) != 2 {
			t.Fatalf("run %d crawled URLs = %v, want seed and child", run+1, seen)
		}
		for _, rawURL := range []string{server.URL, childURL} {
			result, ok := seen[rawURL]
			if !ok {
				t.Errorf("run %d did not crawl %s", run+1, rawURL)
			} else if run == 1 && result.Status != "unchanged" {
				t.Errorf("warm result for %s has status %q, want unchanged", rawURL, result.Status)
			}
		}
	}
	if got := requests.Load(); got != 2 {
		t.Fatalf("HTTP requests after cold and warm crawls = %d, want 2", got)
	}
}

func TestCrawlLegacyCacheBackfillsNavigationLinks(t *testing.T) {
	var requests atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		requests.Add(1)
		w.Header().Set("Content-Type", "text/html")
		if r.URL.Path == "/child" {
			_, _ = w.Write([]byte(`<html><body><main>child</main></body></html>`))
			return
		}
		_, _ = w.Write([]byte(`<html><body><main>root</main></body><nav><a href="/child">Child</a></nav></html>`))
	}))
	t.Cleanup(server.Close)
	pc := newCrawlTestCache(t)
	seed := server.URL + "/"
	pc.Put(server.URL, &scrape.Page{URL: server.URL}, scrape.SourceHTTP)

	for run := 0; run < 2; run++ {
		seen := make(map[string]bool)
		if err := Crawl(t.Context(), seed, scrape.New(), Options{Depth: 1, Concurrency: 1}, pc, false, func(r Result) {
			seen[r.URL] = true
		}); err != nil {
			t.Fatal(err)
		}
		if !seen[server.URL] || !seen[server.URL+"/child"] {
			t.Fatalf("run %d crawled URLs = %v, want seed and child", run+1, seen)
		}
	}
	if got := requests.Load(); got != 2 {
		t.Fatalf("HTTP requests after legacy backfill and warm crawl = %d, want 2", got)
	}
}

func TestCrawlBackfillFailureReturnsCachedPageAndDiagnostic(t *testing.T) {
	var requests atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		requests.Add(1)
		http.Error(w, "offline", http.StatusServiceUnavailable)
	}))
	t.Cleanup(server.Close)
	pc := newCrawlTestCache(t)
	pc.Put(server.URL, &scrape.Page{URL: server.URL, Title: "cached", Markdown: "saved page"}, scrape.SourceHTTP)

	var results []Result
	err := Crawl(t.Context(), server.URL, scrape.New(), Options{Depth: 1, Concurrency: 1}, pc, false, func(r Result) {
		results = append(results, r)
	})
	if err != nil {
		t.Fatal(err)
	}
	if len(results) != 1 {
		t.Fatalf("results = %+v, want one fallback result", results)
	}
	got := results[0]
	if got.Page == nil || got.Page.Title != "cached" || got.Status != "unchanged" {
		t.Fatalf("fallback result = %+v, want cached unchanged page", got)
	}
	if !strings.Contains(got.Error, "link discovery incomplete") || !strings.Contains(got.Error, "503") {
		t.Fatalf("fallback diagnostic = %q, want incomplete links and fetch error", got.Error)
	}
	if requests.Load() != 1 {
		t.Fatalf("backfill requests = %d, want one", requests.Load())
	}
}

func TestCrawlBackfillDoesNotReuseDifferentCacheNamespace(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		http.Error(w, "offline", http.StatusServiceUnavailable)
	}))
	t.Cleanup(server.Close)
	pc := newCrawlTestCache(t)
	pc.Put(server.URL, &scrape.Page{URL: server.URL, Title: "anonymous"}, scrape.SourceHTTP)
	s, err := scrape.NewFromConfig(&config.Config{UserAgent: "configured-agent"})
	if err != nil {
		t.Fatal(err)
	}
	defer s.Close()

	var got Result
	err = Crawl(t.Context(), server.URL, s, Options{Depth: 1, Concurrency: 1}, pc, false, func(r Result) { got = r })
	if err != nil {
		t.Fatal(err)
	}
	if got.Page != nil || got.Error == "" {
		t.Fatalf("result = %+v, want fetch error with no page from another namespace", got)
	}
}

func TestCrawlBackfillDoesNotReuseBrowserStaleCacheEntry(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		http.Error(w, "offline", http.StatusServiceUnavailable)
	}))
	t.Cleanup(server.Close)
	pc := newCrawlTestCache(t)
	pc.Put(server.URL, &scrape.Page{URL: server.URL, Title: "stale shell"}, scrape.SourceHTTPShell)

	var got Result
	if err := Crawl(t.Context(), server.URL, scrape.New(), Options{Depth: 1, Concurrency: 1}, pc, false, func(r Result) { got = r }); err != nil {
		t.Fatal(err)
	}
	if got.Page != nil || got.Error == "" {
		t.Fatalf("result = %+v, want fetch error without browser-stale cached page", got)
	}
}

func TestCrawlDoesNotEmitBackfillFallbackAfterCancellation(t *testing.T) {
	requested := make(chan struct{})
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		close(requested)
		<-r.Context().Done()
	}))
	t.Cleanup(server.Close)
	pc := newCrawlTestCache(t)
	pc.Put(server.URL, &scrape.Page{URL: server.URL, Title: "cached"}, scrape.SourceHTTP)
	ctx, cancel := context.WithCancel(t.Context())
	var results []Result
	done := make(chan error, 1)
	go func() {
		done <- Crawl(ctx, server.URL, scrape.New(), Options{Depth: 1, Concurrency: 1}, pc, false, func(r Result) {
			results = append(results, r)
		})
	}()
	<-requested
	cancel()
	if err := <-done; !errors.Is(err, context.Canceled) {
		t.Fatalf("Crawl error = %v, want context.Canceled", err)
	}
	if len(results) != 0 {
		t.Fatalf("results after cancellation = %+v, want none", results)
	}
}

func TestCrawlDepthLimitAllowsUnknownCacheHit(t *testing.T) {
	var requests atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		requests.Add(1)
	}))
	t.Cleanup(server.Close)
	pc := newCrawlTestCache(t)
	pc.Put(server.URL, &scrape.Page{URL: server.URL}, scrape.SourceHTTP)
	var results []Result
	if err := Crawl(t.Context(), server.URL, scrape.New(), Options{Depth: 0, Concurrency: 1}, pc, false, func(r Result) {
		results = append(results, r)
	}); err != nil {
		t.Fatal(err)
	}
	if len(results) != 1 || results[0].Status != "unchanged" {
		t.Fatalf("results = %+v, want one unchanged seed", results)
	}
	if got := requests.Load(); got != 0 {
		t.Fatalf("HTTP requests at depth limit = %d, want 0", got)
	}
}

func TestCrawlCachesNonHTMLAsKnownLeaf(t *testing.T) {
	var requests atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		requests.Add(1)
		w.Header().Set("Content-Type", "text/plain")
		_, _ = w.Write([]byte("plain text"))
	}))
	t.Cleanup(server.Close)
	pc := newCrawlTestCache(t)
	for range 2 {
		if err := Crawl(t.Context(), server.URL, scrape.New(), Options{Depth: 1, Concurrency: 1}, pc, false, func(Result) {}); err != nil {
			t.Fatal(err)
		}
	}
	if got := requests.Load(); got != 1 {
		t.Fatalf("HTTP requests after cached non-HTML crawl = %d, want 1", got)
	}
}

func TestCrawlCachesEmptyHTMLAsKnownLeaf(t *testing.T) {
	var requests atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		requests.Add(1)
		w.Header().Set("Content-Type", "text/html")
	}))
	t.Cleanup(server.Close)
	pc := newCrawlTestCache(t)
	s := scrape.New()
	defer s.Close()
	for run := 0; run < 2; run++ {
		var results []Result
		if err := Crawl(t.Context(), server.URL, s, Options{Depth: 1, Concurrency: 1}, pc, false, func(r Result) {
			results = append(results, r)
		}); err != nil {
			t.Fatal(err)
		}
		if len(results) != 1 || results[0].Page == nil {
			t.Fatalf("run %d results = %+v, want one page", run+1, results)
		}
		wantStatus := "new"
		if run == 1 {
			wantStatus = "unchanged"
		}
		if results[0].Status != wantStatus {
			t.Errorf("run %d status = %q, want %q", run+1, results[0].Status, wantStatus)
		}
		if run == 0 {
			cached, _, links, known := pc.GetCrawl(server.URL)
			if cached == nil || !known || len(links) != 0 {
				t.Fatalf("empty HTML cache = (page %v, links %v, known %v), want known empty links", cached != nil, links, known)
			}
		}
	}
	if got := requests.Load(); got != 1 {
		t.Fatalf("HTTP requests after two crawls = %d, want 1", got)
	}
}

func TestFeatureNormalizeURL(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name  string
		input string
		want  string
	}{
		{"strips fragment", "https://example.com/page#section", "https://example.com/page"},
		{"strips utm_source", "https://example.com/page?utm_source=twitter&id=1", "https://example.com/page?id=1"},
		{"strips utm_medium", "https://example.com/?utm_medium=email", "https://example.com"},
		{"strips multiple utm params", "https://example.com/p?utm_source=a&utm_medium=b&utm_campaign=c&keep=1", "https://example.com/p?keep=1"},
		{"strips trailing slash", "https://example.com/page/", "https://example.com/page"},
		{"strips fragment and trailing slash", "https://example.com/page/#top", "https://example.com/page"},
		{"preserves query params", "https://example.com/search?q=test&page=2", "https://example.com/search?page=2&q=test"},
		{"empty string", "", ""},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			got := normalizeURL(tt.input)
			if got != tt.want {
				t.Errorf("normalizeURL(%q) = %q, want %q", tt.input, got, tt.want)
			}
		})
	}
}

func TestCrawlRejectsFileSeed(t *testing.T) {
	err := Crawl(t.Context(), "file:///etc/passwd", scrape.New(), Options{Concurrency: 1}, nil, false, func(Result) {})
	if !errors.Is(err, scrape.ErrInvalidURL) {
		t.Fatalf("Crawl error = %v, want ErrInvalidURL", err)
	}
}

func TestCrawlUsesRewrittenSeedHost(t *testing.T) {
	target := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html")
		if r.URL.Path == "/" {
			_, _ = w.Write([]byte(`<html><body><a href="/child">child</a></body></html>`))
			return
		}
		_, _ = w.Write([]byte(`<html><body><main>child page</main></body></html>`))
	}))
	t.Cleanup(target.Close)
	rw, err := urlrewrite.NewRewriter([]urlrewrite.Rule{{Match: `^https://source\.invalid/`, Replace: target.URL + "/"}})
	if err != nil {
		t.Fatal(err)
	}
	s := scrape.NewWithRewriter("", rw)
	seen := make(map[string]bool)
	err = Crawl(t.Context(), "https://source.invalid/", s, Options{Depth: 1, Concurrency: 1}, nil, false, func(r Result) {
		if r.Error != "" {
			t.Errorf("crawl %s: %s", r.URL, r.Error)
		}
		seen[r.URL] = true
	})
	if err != nil {
		t.Fatal(err)
	}
	if !seen[target.URL] || !seen[target.URL+"/child"] {
		t.Fatalf("crawled URLs = %v, want target seed and child", seen)
	}
}

func TestCrawlRewritesSitemapAndNestedIndex(t *testing.T) {
	const source = "https://source.invalid"
	target := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/sitemap.xml":
			w.Header().Set("Content-Type", "application/xml")
			_, _ = w.Write([]byte(`<sitemapindex><sitemap><loc>` + source + `/nested.xml</loc></sitemap></sitemapindex>`))
		case "/nested.xml":
			w.Header().Set("Content-Type", "application/xml")
			_, _ = w.Write([]byte(`<urlset><url><loc>` + source + `/page</loc></url></urlset>`))
		case "/page":
			w.Header().Set("Content-Type", "text/html")
			_, _ = w.Write([]byte(`<html><body><main>page</main></body></html>`))
		default:
			http.NotFound(w, r)
		}
	}))
	t.Cleanup(target.Close)
	rw, err := urlrewrite.NewRewriter([]urlrewrite.Rule{{Match: `^https://source\.invalid/`, Replace: target.URL + "/"}})
	if err != nil {
		t.Fatal(err)
	}
	s := scrape.NewWithRewriter("", rw)
	var got []Result
	err = Crawl(t.Context(), source+"/sitemap.xml", s, Options{Concurrency: 1}, nil, true, func(r Result) {
		got = append(got, r)
	})
	if err != nil {
		t.Fatal(err)
	}
	if len(got) != 1 || got[0].URL != target.URL+"/page" || got[0].Error != "" {
		t.Fatalf("crawl results = %+v, want rewritten sitemap page", got)
	}
}

func TestFeatureSameHostFiltering(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		url      string
		seedHost string
		want     bool
	}{
		{"same host passes", "https://example.com/page", "example.com", true},
		{"different host rejected", "https://other.com/page", "example.com", false},
		{"subdomain rejected", "https://sub.example.com/page", "example.com", false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			got := passesFilters(tt.url, tt.seedHost, nil, nil)
			if got != tt.want {
				t.Errorf("passesFilters(%q, %q) = %v, want %v", tt.url, tt.seedHost, got, tt.want)
			}
		})
	}
}

func TestFeatureAllowFilter(t *testing.T) {
	t.Parallel()

	allow := []string{"/docs", "/api"}

	tests := []struct {
		name string
		url  string
		want bool
	}{
		{"matches /docs", "https://example.com/docs/intro", true},
		{"matches /api", "https://example.com/api/v1/users", true},
		{"no match rejected", "https://example.com/blog/post", false},
		{"root rejected", "https://example.com/", false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			got := passesFilters(tt.url, "example.com", allow, nil)
			if got != tt.want {
				t.Errorf("passesFilters(%q, allow=%v) = %v, want %v", tt.url, allow, got, tt.want)
			}
		})
	}
}

func TestFeatureDenyFilter(t *testing.T) {
	t.Parallel()

	deny := []*regexp.Regexp{
		regexp.MustCompile(`/admin`),
		regexp.MustCompile(`\.pdf$`),
	}

	tests := []struct {
		name string
		url  string
		want bool
	}{
		{"normal page passes", "https://example.com/page", true},
		{"/admin denied", "https://example.com/admin/dashboard", false},
		{"PDF denied", "https://example.com/doc.pdf", false},
		{"/docs passes", "https://example.com/docs/guide", true},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			got := passesFilters(tt.url, "example.com", nil, deny)
			if got != tt.want {
				t.Errorf("passesFilters(%q, deny) = %v, want %v", tt.url, got, tt.want)
			}
		})
	}
}

func TestFeatureExtractLinksFromHTML(t *testing.T) {
	t.Parallel()

	html := `<html><body>
		<a href="/about">About</a>
		<a href="https://example.com/contact">Contact</a>
		<a href="../other">Other</a>
		<a href="javascript:void(0)">JS link</a>
		<a href="mailto:test@example.com">Email</a>
		<a href="tel:+1234567890">Phone</a>
		<a href="#section">Anchor</a>
		<a href="https://external.com/page">External</a>
	</body></html>`

	links := extractLinks("https://example.com/docs/page", nil, html)

	// Should resolve relative URLs
	found := make(map[string]bool)
	for _, l := range links {
		found[l] = true
	}

	// Relative /about should resolve to https://example.com/about
	if !found["https://example.com/about"] {
		t.Error("expected /about to resolve to https://example.com/about")
	}

	// Absolute URL preserved
	if !found["https://example.com/contact"] {
		t.Error("expected absolute URL to be preserved")
	}

	// ../other should resolve relative to /docs/page
	if !found["https://example.com/other"] {
		t.Error("expected ../other to resolve to https://example.com/other")
	}

	// External links should be included (filtering is separate)
	if !found["https://external.com/page"] {
		t.Error("expected external link to be extracted")
	}

	// javascript:, mailto:, tel:, # should be skipped
	for _, l := range links {
		if strings.HasPrefix(l, "javascript:") || strings.HasPrefix(l, "mailto:") ||
			strings.HasPrefix(l, "tel:") {
			t.Errorf("should skip non-HTTP link: %s", l)
		}
	}
}

func TestExtractLinksDeduplicatesExactResolvedURLsInOrder(t *testing.T) {
	got := extractLinks("https://example.com/docs/", nil, `<a href="/a">first</a><a href="/b">second</a><a href="/a">duplicate</a><a href="/a?x=1">distinct</a>`)
	want := []string{"https://example.com/a", "https://example.com/b", "https://example.com/a?x=1"}
	if len(got) != len(want) {
		t.Fatalf("links = %v, want %v", got, want)
	}
	for i := range want {
		if got[i] != want[i] {
			t.Fatalf("links = %v, want %v", got, want)
		}
	}
}

func TestFeatureSitemapXMLParsing(t *testing.T) {
	t.Parallel()

	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/xml")
		sitemap := urlSet{
			XMLName: xml.Name{Local: "urlset"},
			URLs: []urlLoc{
				{Loc: "https://example.com/page1"},
				{Loc: "https://example.com/page2"},
				{Loc: "https://example.com/page3"},
			},
		}
		data, _ := xml.Marshal(sitemap)
		w.Write(data)
	}))
	defer server.Close()

	s := scrape.New()
	defer s.Close()
	urls, err := fetchSitemap(context.Background(), s, server.URL)
	if err != nil {
		t.Fatalf("fetchSitemap error: %v", err)
	}
	if len(urls) != 3 {
		t.Fatalf("got %d URLs, want 3", len(urls))
	}

	sort.Strings(urls)
	expected := []string{
		"https://example.com/page1",
		"https://example.com/page2",
		"https://example.com/page3",
	}
	for i, want := range expected {
		if urls[i] != want {
			t.Errorf("url[%d] = %q, want %q", i, urls[i], want)
		}
	}
}

func TestFeatureSitemapIndexParsing(t *testing.T) {
	t.Parallel()

	mux := http.NewServeMux()
	server := httptest.NewServer(mux)
	defer server.Close()

	// Sitemap index points to a child sitemap
	mux.HandleFunc("/sitemap.xml", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/xml")
		idx := sitemapIndex{
			XMLName:  xml.Name{Local: "sitemapindex"},
			Sitemaps: []sitemapLoc{{Loc: server.URL + "/sitemap-pages.xml"}},
		}
		data, _ := xml.Marshal(idx)
		w.Write(data)
	})

	mux.HandleFunc("/sitemap-pages.xml", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/xml")
		us := urlSet{
			XMLName: xml.Name{Local: "urlset"},
			URLs:    []urlLoc{{Loc: "https://example.com/from-index"}},
		}
		data, _ := xml.Marshal(us)
		w.Write(data)
	})

	s := scrape.New()
	defer s.Close()
	urls, err := fetchSitemap(context.Background(), s, server.URL+"/sitemap.xml")
	if err != nil {
		t.Fatalf("fetchSitemap error: %v", err)
	}
	if len(urls) != 1 {
		t.Fatalf("got %d URLs, want 1", len(urls))
	}
	if urls[0] != "https://example.com/from-index" {
		t.Errorf("url = %q, want %q", urls[0], "https://example.com/from-index")
	}
}

func TestAuthenticatedSitemapAndNestedIndex(t *testing.T) {
	const wantCookie = "session=secret"
	mux := http.NewServeMux()
	server := httptest.NewServer(mux)
	defer server.Close()

	mux.HandleFunc("/sitemap.xml", func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Cookie") != wantCookie {
			http.Error(w, "unauthorized", http.StatusUnauthorized)
			return
		}
		idx := sitemapIndex{
			XMLName:  xml.Name{Local: "sitemapindex"},
			Sitemaps: []sitemapLoc{{Loc: server.URL + "/nested.xml"}},
		}
		_ = xml.NewEncoder(w).Encode(idx)
	})
	mux.HandleFunc("/nested.xml", func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Cookie") != wantCookie {
			http.Error(w, "unauthorized", http.StatusUnauthorized)
			return
		}
		us := urlSet{
			XMLName: xml.Name{Local: "urlset"},
			URLs:    []urlLoc{{Loc: server.URL + "/private"}},
		}
		_ = xml.NewEncoder(w).Encode(us)
	})

	jarPath := filepath.Join(t.TempDir(), "cookies.txt")
	if err := os.WriteFile(jarPath, []byte("127.0.0.1\tFALSE\t/\tFALSE\t0\tsession\tsecret\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	s, err := scrape.NewFromConfig(&config.Config{CookieFile: jarPath})
	if err != nil {
		t.Fatal(err)
	}
	defer s.Close()

	urls, err := fetchSitemap(context.Background(), s, server.URL+"/sitemap.xml")
	if err != nil {
		t.Fatalf("fetchSitemap: %v", err)
	}
	if len(urls) != 1 || urls[0] != server.URL+"/private" {
		t.Fatalf("urls = %v, want authenticated nested sitemap URL", urls)
	}
}

func TestFeatureVisitedDeduplication(t *testing.T) {
	t.Parallel()

	c := &crawler{
		visited: make(map[string]bool),
	}

	// First visit should succeed
	if !c.tryVisit("https://example.com/page") {
		t.Error("first visit should return true")
	}

	// Second visit to same URL should fail
	if c.tryVisit("https://example.com/page") {
		t.Error("second visit to same URL should return false")
	}

	// Different URL should succeed
	if !c.tryVisit("https://example.com/other") {
		t.Error("visit to different URL should return true")
	}
}

func TestFeatureCompileDeny(t *testing.T) {
	t.Parallel()

	// Valid patterns compile
	regexps, err := compileDeny([]string{`/admin`, `\.pdf$`})
	if err != nil {
		t.Fatalf("compileDeny error: %v", err)
	}
	if len(regexps) != 2 {
		t.Errorf("got %d regexps, want 2", len(regexps))
	}

	// Invalid pattern returns error
	_, err = compileDeny([]string{`[invalid`})
	if err == nil {
		t.Error("expected error for invalid regex pattern")
	}
}

func TestFeatureNormalizeURLPreservesSchemeHost(t *testing.T) {
	t.Parallel()

	got := normalizeURL("https://example.com/path?key=value")
	if got != "https://example.com/path?key=value" {
		t.Errorf("normalizeURL should preserve scheme/host/path/query, got %q", got)
	}
}

// TestCrawlSchedulerEndToEnd stands up a small site where every page links
// to every other, then verifies the scheduler visits each page exactly
// once and terminates cleanly. Also exercises context cancellation.
func TestCrawlSchedulerEndToEnd(t *testing.T) {
	t.Parallel()

	pages := []string{"/", "/a", "/b", "/c", "/d"}
	pageSet := map[string]bool{}
	for _, p := range pages {
		pageSet[p] = true
	}

	mux := http.NewServeMux()
	for _, p := range pages {
		mux.HandleFunc(p, func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Type", "text/html")
			var b strings.Builder
			b.WriteString(`<!doctype html><html><body><main><article>`)
			b.WriteString(`<h1>Page</h1><p>content content content content content content content content content content content content content content content content content content content content content content content content</p>`)
			for _, q := range pages {
				b.WriteString(`<a href="` + q + `">link</a>`)
			}
			b.WriteString(`</article></main></body></html>`)
			_, _ = w.Write([]byte(b.String()))
		})
	}
	server := httptest.NewServer(mux)
	defer server.Close()

	var mu sync.Mutex
	seen := map[string]int{}
	fn := func(r Result) {
		if r.Error != "" {
			return
		}
		mu.Lock()
		seen[r.URL]++
		mu.Unlock()
	}

	opts := Options{Depth: 5, Concurrency: 4}
	// Use exported entry point to exercise the full wiring.
	s := scrape.New()
	defer s.Close()
	if err := Crawl(t.Context(), server.URL, s, opts, nil, false, fn); err != nil {
		t.Fatalf("Crawl error: %v", err)
	}

	if len(seen) != len(pages) {
		t.Fatalf("visited %d pages, want %d: %v", len(seen), len(pages), seen)
	}
	for u, n := range seen {
		if n != 1 {
			t.Errorf("URL %s visited %d times, want 1", u, n)
		}
	}
}

type crawlCountingBrowser struct {
	calls atomic.Int32
}

func (b *crawlCountingBrowser) Fetch(context.Context, string) (string, error) {
	b.calls.Add(1)
	return `<html><body>Chromium PDF viewer</body></html>`, nil
}

func (b *crawlCountingBrowser) Close() {}

func TestCrawlHostHeuristicDoesNotRenderPDF(t *testing.T) {
	pdf, err := os.ReadFile("../extract/testdata/simple.pdf")
	if err != nil {
		t.Fatalf("read PDF fixture: %v", err)
	}
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Content-Type", "application/pdf")
		_, _ = w.Write(pdf)
	}))
	t.Cleanup(server.Close)
	parsed, err := url.Parse(server.URL)
	if err != nil {
		t.Fatalf("parse server URL: %v", err)
	}

	browser := &crawlCountingBrowser{}
	s := scrape.NewWithBrowserConn(browser, nil)
	var got Result
	c := &crawler{
		ctx:       t.Context(),
		scraper:   s,
		opts:      Options{Depth: 1},
		fn:        func(result Result) { got = result },
		hostStats: map[string]*hostJSStats{parsed.Hostname(): {total: 10, shells: 10}},
	}
	c.processItem(queueItem{url: server.URL + "/document.pdf", source: "link"})

	if got.Error != "" {
		t.Fatalf("crawl result error = %q", got.Error)
	}
	if got.Page == nil || !strings.Contains(got.Page.Markdown, "Ketch PDF extraction works.") {
		t.Fatalf("crawl page = %#v", got.Page)
	}
	if browser.calls.Load() != 0 {
		t.Fatalf("browser calls = %d, want 0", browser.calls.Load())
	}
}

func TestCrawlDoesNotFollowLinksFromNonHTML(t *testing.T) {
	t.Parallel()

	var trapHits atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/trap" {
			trapHits.Add(1)
		}
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"embedded_html":"<a href='/trap'>must not be crawled</a>"}`))
	}))
	defer server.Close()

	s := scrape.New()
	defer s.Close()
	if err := Crawl(t.Context(), server.URL, s, Options{Depth: 2, Concurrency: 2}, nil, false, func(Result) {}); err != nil {
		t.Fatalf("Crawl: %v", err)
	}
	if trapHits.Load() != 0 {
		t.Fatalf("followed a link from non-HTML content %d times", trapHits.Load())
	}
}

func TestCrawlSchedulerCancels(t *testing.T) {
	t.Parallel()

	// Server that blocks until the test releases it — simulates slow peers.
	release := make(chan struct{})
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		select {
		case <-release:
		case <-r.Context().Done():
			return
		}
		_, _ = w.Write([]byte(`<html><body><main><article><p>` + strings.Repeat("x", 300) + `</p></article></main></body></html>`))
	}))
	defer server.Close()
	defer close(release)

	ctx, cancel := context.WithCancel(t.Context())
	// Cancel soon after the crawl starts so in-flight requests abort.
	time.AfterFunc(50*time.Millisecond, cancel)

	opts := Options{Depth: 3, Concurrency: 4}
	s := scrape.New()
	defer s.Close()
	err := Crawl(ctx, server.URL, s, opts, nil, false, func(Result) {})
	if err == nil {
		t.Fatal("expected context error, got nil")
	}
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("expected context.Canceled, got %v", err)
	}
}
