package doctor

import (
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/1broseidon/ketch/cache"
	"github.com/1broseidon/ketch/config"
	"github.com/1broseidon/ketch/internal/testutil"
	"github.com/1broseidon/ketch/search"
)

// roundTripFunc adapts a function to http.RoundTripper.
type roundTripFunc func(*http.Request) (*http.Response, error)

func (f roundTripFunc) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

func testCtx(t *testing.T) context.Context {
	t.Helper()
	return context.Background()
}

func TestProbeFirecrawlNoKey(t *testing.T) {
	var sawAuth bool
	var gotURL, gotBody string
	client := &http.Client{Transport: probeRoundTripFunc(func(req *http.Request) (*http.Response, error) {
		gotURL = req.URL.String()
		if req.Header.Get("Authorization") != "" {
			sawAuth = true
		}
		b, _ := io.ReadAll(req.Body)
		gotBody = string(b)
		return &http.Response{StatusCode: http.StatusOK, Header: make(http.Header), Body: io.NopCloser(strings.NewReader(`{}`))}, nil
	})}

	status, detail := probeFirecrawl(testCtx(t), client, config.FirecrawlSearchURL(config.DefaultFirecrawlURL), "")
	if status != StatusOK {
		t.Fatalf("status = %q (detail %q), want ok", status, detail)
	}
	if sawAuth {
		t.Fatal("hosted keyless probe must omit Authorization")
	}
	if gotURL != config.FirecrawlSearchURL(config.DefaultFirecrawlURL) {
		t.Errorf("url = %q, want hosted /v2/search", gotURL)
	}
	if strings.Contains(gotBody, "integration") {
		t.Errorf("probe body %q contains an integration tracking tag", gotBody)
	}
}

func TestProbeFirecrawlHostedStatuses(t *testing.T) {
	cases := []struct {
		name       string
		key        string
		code       int
		want       Status
		wantDetail string // substring; empty skips the detail check
	}{
		{"keyless ok", "", http.StatusOK, StatusOK, ""},
		{"keyless rate limited", "", http.StatusTooManyRequests, StatusOK, "rate limited"},
		{"keyless credits", "", http.StatusPaymentRequired, StatusMisconfigured, "credits exhausted"},
		{"keyless unauthorized", "", http.StatusUnauthorized, StatusMisconfigured, "request rejected"},
		{"keyless forbidden", "", http.StatusForbidden, StatusOK, "keyless blocked"},
		{"keyed rate limited", "k", http.StatusTooManyRequests, StatusOK, "key accepted"},
		{"keyed rejected", "k", http.StatusUnauthorized, StatusMisconfigured, "API key rejected"},
		{"keyed forbidden", "k", http.StatusForbidden, StatusMisconfigured, "API key rejected"},
		{"keyed credits", "k", http.StatusPaymentRequired, StatusMisconfigured, "credits exhausted"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			client := &http.Client{Transport: probeRoundTripFunc(func(req *http.Request) (*http.Response, error) {
				return &http.Response{StatusCode: tc.code, Header: make(http.Header), Body: io.NopCloser(strings.NewReader(`{}`))}, nil
			})}
			status, detail := probeFirecrawl(testCtx(t), client, config.FirecrawlSearchURL(config.DefaultFirecrawlURL), tc.key)
			if status != tc.want {
				t.Fatalf("status = %q (detail %q), want %q", status, detail, tc.want)
			}
			if tc.wantDetail != "" && !strings.Contains(detail, tc.wantDetail) {
				t.Errorf("detail = %q, want substring %q", detail, tc.wantDetail)
			}
		})
	}
}

func TestProbeFirecrawlSelfHostedNoKey(t *testing.T) {
	var sawAuth bool
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") != "" {
			sawAuth = true
		}
		w.WriteHeader(http.StatusOK)
	}))
	defer ts.Close()

	status, _ := probeFirecrawl(testCtx(t), ts.Client(), ts.URL, "")
	if status != StatusOK {
		t.Fatalf("status = %q, want ok", status)
	}
	if sawAuth {
		t.Fatal("self-hosted keyless probe must omit Authorization")
	}
}

func TestProbeTimeout(t *testing.T) {
	slow := spec{surface: "search", backend: "slow", minTimeout: SelfHostedSearchTimeout}
	ordinary := spec{surface: "search", backend: "ordinary"}

	if got := probeTimeout(slow, DefaultTimeout); got != SelfHostedSearchTimeout {
		t.Errorf("slow budget = %v, want %v", got, SelfHostedSearchTimeout)
	}
	if got := probeTimeout(ordinary, DefaultTimeout); got != DefaultTimeout {
		t.Errorf("ordinary budget = %v, want the run timeout %v", got, DefaultTimeout)
	}
	if got := probeTimeout(slow, time.Minute); got != time.Minute {
		t.Errorf("slow budget = %v, want the caller's longer %v", got, time.Minute)
	}
}

func TestProbeFirecrawlSelfHostedLiveness(t *testing.T) {
	var body string
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		b, _ := io.ReadAll(r.Body)
		body = string(b)
		w.WriteHeader(http.StatusBadRequest)
	}))
	defer ts.Close()

	status, detail := probeFirecrawl(testCtx(t), ts.Client(), ts.URL, "")
	if status != StatusOK {
		t.Fatalf("status = %q, want ok: a rejected body still proves /v2/search answers", status)
	}
	if !strings.Contains(detail, "liveness") {
		t.Errorf("detail %q should say no real search ran", detail)
	}
	if strings.Contains(body, "query") {
		t.Errorf("self-hosted probe body = %q, want one that never starts a search", body)
	}
}

func TestProbeFirecrawlSelfHostedWrongBase(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusNotFound)
	}))
	defer ts.Close()

	status, detail := probeFirecrawl(testCtx(t), ts.Client(), ts.URL, "")
	if status != StatusUnreachable {
		t.Fatalf("status = %q, want unreachable", status)
	}
	if !strings.Contains(detail, "firecrawl_url") {
		t.Errorf("detail %q should point at firecrawl_url", detail)
	}
}

func TestProbeFirecrawlStatuses(t *testing.T) {
	cases := []struct {
		name string
		code int
		want Status
	}{
		{"ok", http.StatusOK, StatusOK},
		{"invalid key", http.StatusUnauthorized, StatusMisconfigured},
		{"payment required", http.StatusPaymentRequired, StatusMisconfigured},
		{"rate limited", http.StatusTooManyRequests, StatusOK},
		{"server error", http.StatusBadGateway, StatusUnreachable},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				if got := r.Method; got != http.MethodPost {
					t.Errorf("method = %q, want POST", got)
				}
				if got := r.Header.Get("Authorization"); got != "Bearer k" {
					t.Errorf("Authorization = %q, want Bearer k", got)
				}
				w.WriteHeader(tc.code)
			}))
			defer ts.Close()

			status, _ := probeFirecrawl(testCtx(t), ts.Client(), ts.URL, "k")
			if status != tc.want {
				t.Fatalf("status = %q, want %q", status, tc.want)
			}
		})
	}
}

// --- ddg ---

func TestProbeDDGStatuses(t *testing.T) {
	cases := []struct {
		name string
		code int
		want Status
	}{
		{"ok", http.StatusOK, StatusOK},
		{"rate limited", http.StatusAccepted, StatusOK},
		{"blocked", http.StatusForbidden, StatusUnreachable},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
				w.WriteHeader(tc.code)
			}))
			defer ts.Close()

			status, _ := probeDDG(testCtx(t), ts.Client(), ts.URL)
			if status != tc.want {
				t.Fatalf("status = %q, want %q", status, tc.want)
			}
		})
	}
}

// --- MCP endpoints ---

func TestProbeMCP(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			t.Errorf("method = %s, want POST", r.Method)
		}
		_, _ = w.Write([]byte(`{"jsonrpc":"2.0","id":1,"result":{"tools":[]}}`))
	}))
	defer ts.Close()

	if status, detail := probeMCP(testCtx(t), ts.Client(), ts.URL, "grep.app"); status != StatusOK {
		t.Fatalf("status = %q (detail %q), want ok", status, detail)
	}
}

func TestProbeMCPServerError(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusServiceUnavailable)
	}))
	defer ts.Close()

	status, detail := probeMCP(testCtx(t), ts.Client(), ts.URL, "parallel")
	if status != StatusUnreachable {
		t.Fatalf("status = %q, want unreachable", status)
	}
	if !strings.Contains(detail, "parallel") {
		t.Errorf("detail %q should name the backend", detail)
	}
}

type probeRoundTripFunc func(*http.Request) (*http.Response, error)

func (f probeRoundTripFunc) RoundTrip(req *http.Request) (*http.Response, error) {
	return f(req)
}

// --- keenable ---

func TestProbeKeenableKeyless(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			t.Errorf("method = %s, want POST", r.Method)
		}
		if got := r.URL.Path; got != "/v1/search/public" {
			t.Errorf("path = %q, want /v1/search/public (keyless)", got)
		}
		if got := r.Header.Get("X-API-Key"); got != "" {
			t.Errorf("X-API-Key = %q, want empty for keyless", got)
		}
		w.WriteHeader(http.StatusOK)
	}))
	defer ts.Close()

	status, detail := probeKeenable(testCtx(t), ts.Client(), ts.URL, "")
	if status != StatusOK {
		t.Fatalf("status = %q (detail %q), want ok", status, detail)
	}
}

func TestProbeKeenableKeyRejected(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if got := r.URL.Path; got != "/v1/search" {
			t.Errorf("path = %q, want /v1/search (keyed)", got)
		}
		w.WriteHeader(http.StatusUnauthorized)
	}))
	defer ts.Close()

	status, _ := probeKeenable(testCtx(t), ts.Client(), ts.URL, "bad-key")
	if status != StatusMisconfigured {
		t.Fatalf("status = %q, want misconfigured", status)
	}
}

// --- sourcegraph reachability ---

func TestProbeReachable(t *testing.T) {
	cases := []struct {
		name string
		code int
		want Status
	}{
		{"ok", http.StatusOK, StatusOK},
		{"auth wall still reachable", http.StatusUnauthorized, StatusOK},
		{"server down", http.StatusBadGateway, StatusUnreachable},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
				w.WriteHeader(tc.code)
			}))
			defer ts.Close()

			status, _ := probeReachable(testCtx(t), ts.Client(), ts.URL, "sourcegraph")
			if status != tc.want {
				t.Fatalf("status = %q, want %q", status, tc.want)
			}
		})
	}
}

// --- github ---

func TestProbeGitHubNoToken(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(_ http.ResponseWriter, _ *http.Request) {
		t.Error("no-token probe must not hit the network")
	}))
	defer ts.Close()

	status, detail := probeGitHub(testCtx(t), ts.Client(), ts.URL, func() (string, string) { return "", "none" })
	if status != StatusNoKey {
		t.Fatalf("status = %q, want no_key", status)
	}
	if !strings.Contains(detail, "gh auth login") {
		t.Errorf("detail %q should carry the resolution hint", detail)
	}
}

func TestProbeGitHubTokenAccepted(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if got := r.Header.Get("Authorization"); got != "Bearer tok" {
			t.Errorf("auth header = %q", got)
		}
		if r.URL.Path != "/rate_limit" {
			t.Errorf("path = %q, want /rate_limit", r.URL.Path)
		}
		_, _ = w.Write([]byte(`{}`))
	}))
	defer ts.Close()

	status, detail := probeGitHub(testCtx(t), ts.Client(), ts.URL, func() (string, string) { return "tok", "gh-cli" })
	if status != StatusOK {
		t.Fatalf("status = %q, want ok", status)
	}
	if !strings.Contains(detail, "gh-cli") {
		t.Errorf("detail %q should report the token source", detail)
	}
}

func TestProbeGitHubTokenRejected(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusUnauthorized)
	}))
	defer ts.Close()

	status, _ := probeGitHub(testCtx(t), ts.Client(), ts.URL, func() (string, string) { return "bad", "env" })
	if status != StatusMisconfigured {
		t.Fatalf("status = %q, want misconfigured", status)
	}
}

// --- context7 ---

func TestProbeContext7Keyless(t *testing.T) {
	// With no key the probe sends nothing (each request spends the
	// anonymous quota) and reports the quota a real Context7 response last
	// left in ketch's cache directory.
	noRequests := &http.Client{Transport: roundTripFunc(func(r *http.Request) (*http.Response, error) {
		t.Errorf("keyless probe sent %s", r.URL)
		return nil, errors.New("no requests")
	})}
	keyless := func(t *testing.T, state string) (Status, string) {
		home := testutil.SetIsolatedConfigHome(t)
		if state != "" {
			base, err := os.UserCacheDir()
			if err != nil || !strings.HasPrefix(base, home) {
				t.Fatalf("cache dir %q not isolated under %q: %v", base, home, err)
			}
			if err := os.MkdirAll(filepath.Join(base, "ketch"), 0o700); err != nil {
				t.Fatal(err)
			}
			if err := os.WriteFile(filepath.Join(base, "ketch", "context7-quota.json"), []byte(state), 0o600); err != nil {
				t.Fatal(err)
			}
		}
		return probeContext7(testCtx(t), noRequests, "http://unused.invalid", "")
	}
	t.Run("keyless, quota not yet seen", func(t *testing.T) {
		status, detail := keyless(t, "")
		if status != StatusOK || !strings.HasPrefix(detail, "keyless (quota not yet seen;") {
			t.Fatalf("got %q %q", status, detail)
		}
	})
	t.Run("keyless, quota seen", func(t *testing.T) {
		status, detail := keyless(t, `{"keyless":{"limit":200,"remaining":187,"reset":"2999-12-01T00:00:00Z","observed_at":"2026-11-02T13:30:00Z"}}`)
		want := "keyless (~187 of 200 left as of 2026-11-02 13:30 UTC, resets 2999-12-01 00:00 UTC; a key lifts the cap: ketch config set context7_api_key <key>)"
		if status != StatusOK || detail != want {
			t.Fatalf("got %q %q, want ok %q", status, detail, want)
		}
	})
	t.Run("keyless quota spent", func(t *testing.T) {
		status, detail := keyless(t, `{"keyless":{"limit":200,"remaining":0,"reset":"2999-12-01T00:00:00Z","observed_at":"2026-11-02T13:30:00Z"}}`)
		if status != StatusNoKey || !strings.Contains(detail, "2999-12-01 00:00 UTC") || !strings.Contains(detail, "ketch config set context7_api_key") {
			t.Fatalf("got %q %q, want no_key naming the reset and the key fix", status, detail)
		}
	})
}

func TestProbeContext7(t *testing.T) {
	t.Run("key rejected", func(t *testing.T) {
		ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
			w.WriteHeader(http.StatusUnauthorized)
		}))
		defer ts.Close()
		status, _ := probeContext7(testCtx(t), ts.Client(), ts.URL, "bad")
		if status != StatusMisconfigured {
			t.Fatalf("status = %q, want misconfigured", status)
		}
	})
	t.Run("ok", func(t *testing.T) {
		ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			if got := r.Header.Get("Authorization"); got != "Bearer k" {
				t.Errorf("auth header = %q", got)
			}
			_, _ = w.Write([]byte(`{"results":[]}`))
		}))
		defer ts.Close()
		status, detail := probeContext7(testCtx(t), ts.Client(), ts.URL, "k")
		if status != StatusOK || detail != "" {
			t.Fatalf("status = %q detail %q, want ok and no detail", status, detail)
		}
	})
}

// --- browser ---

func TestCheckBrowser(t *testing.T) {
	t.Run("unconfigured is a clean skip", func(t *testing.T) {
		status, _ := checkBrowser("")
		if status != StatusSkipped {
			t.Fatalf("status = %q, want skipped", status)
		}
	})
	t.Run("missing binary", func(t *testing.T) {
		status, _ := checkBrowser(filepath.Join(t.TempDir(), "no-such-browser"))
		if status != StatusMisconfigured {
			t.Fatalf("status = %q, want misconfigured", status)
		}
	})
	t.Run("existing binary", func(t *testing.T) {
		bin := filepath.Join(t.TempDir(), "chrome")
		if err := os.WriteFile(bin, []byte("#!/bin/sh\n"), 0o755); err != nil {
			t.Fatal(err)
		}
		status, detail := checkBrowser(bin)
		if status != StatusOK {
			t.Fatalf("status = %q (detail %q), want ok", status, detail)
		}
		if detail != bin {
			t.Errorf("detail = %q, want resolved path %q", detail, bin)
		}
	})
}

// --- cookies ---

func writeCookieJar(t *testing.T, mode os.FileMode, lines ...string) string {
	t.Helper()
	path := filepath.Join(t.TempDir(), "cookies.txt")
	if err := os.WriteFile(path, []byte(strings.Join(lines, "\n")+"\n"), mode); err != nil {
		t.Fatal(err)
	}
	if err := os.Chmod(path, mode); err != nil {
		t.Fatal(err)
	}
	return path
}

func TestCheckCookieFile(t *testing.T) {
	future := time.Now().Add(24 * time.Hour).Unix()
	past := time.Now().Add(-24 * time.Hour).Unix()
	live := func(name string) string {
		return fmt.Sprintf("example.com\tTRUE\t/\tFALSE\t%d\t%s\tsecretval", future, name)
	}
	expired := fmt.Sprintf("example.com\tTRUE\t/\tFALSE\t%d\told\tsecretval", past)

	t.Run("unconfigured is a clean skip", func(t *testing.T) {
		status, _ := checkCookieFile("")
		if status != StatusSkipped {
			t.Fatalf("status = %q, want skipped", status)
		}
	})

	t.Run("valid jar reports counts", func(t *testing.T) {
		jar := writeCookieJar(t, 0o600, live("a"), live("b"), expired)
		status, detail := checkCookieFile(jar)
		if status != StatusOK {
			t.Fatalf("status = %q (detail %q), want ok", status, detail)
		}
		if detail != "configured (2 cookies, 1 expired)" {
			t.Fatalf("detail = %q", detail)
		}
		if strings.Contains(detail, "secretval") {
			t.Fatal("detail leaked a cookie value")
		}
	})

	t.Run("loose perms warn in detail", func(t *testing.T) {
		if runtime.GOOS == "windows" {
			t.Skip("POSIX perms not meaningful on Windows")
		}
		jar := writeCookieJar(t, 0o644, live("a"))
		_, detail := checkCookieFile(jar)
		if !strings.Contains(detail, "group/world-readable") {
			t.Fatalf("detail = %q, want chmod hint", detail)
		}
	})

	t.Run("missing path is misconfigured", func(t *testing.T) {
		status, _ := checkCookieFile("/nonexistent/jar.txt")
		if status != StatusMisconfigured {
			t.Fatalf("status = %q, want misconfigured", status)
		}
	})
}

// --- tags ---

func TestCheckTags(t *testing.T) {
	t.Run("no tags.db yet is a clean skip", func(t *testing.T) {
		t.Setenv("KETCH_TAGS_PATH", filepath.Join(t.TempDir(), "tags.db"))
		status, detail := checkTags()
		if status != StatusSkipped {
			t.Fatalf("status = %q (detail %q), want skipped", status, detail)
		}
	})

	t.Run("existing index reports counts", func(t *testing.T) {
		t.Setenv("KETCH_TAGS_PATH", filepath.Join(t.TempDir(), "tags.db"))
		index := cache.NewTagIndex(time.Hour, nil)
		if _, err := index.TagURL("project", "https://example.test", "https://example.test"); err != nil {
			t.Fatal(err)
		}
		status, detail := checkTags()
		if status != StatusOK {
			t.Fatalf("status = %q (detail %q), want ok", status, detail)
		}
		if !strings.Contains(detail, "1 tag") || !strings.Contains(detail, "1 entry") {
			t.Fatalf("detail = %q, want it to mention 1 tag and 1 entry", detail)
		}
	})

	t.Run("path that is a directory is misconfigured", func(t *testing.T) {
		t.Setenv("KETCH_TAGS_PATH", t.TempDir())
		status, detail := checkTags()
		if status != StatusMisconfigured {
			t.Fatalf("status = %q (detail %q), want misconfigured", status, detail)
		}
	})

	t.Run("read-only, never writes the file into existence", func(t *testing.T) {
		path := filepath.Join(t.TempDir(), "tags.db")
		t.Setenv("KETCH_TAGS_PATH", path)
		if status, detail := checkTags(); status != StatusSkipped {
			t.Fatalf("status = %q (detail %q), want skipped", status, detail)
		}
		if _, err := os.Stat(path); !errors.Is(err, os.ErrNotExist) {
			t.Fatalf("checkTags created tags.db: %v", err)
		}
	})
}

// --- exit gating: which checks are required ---

func findSpec(t *testing.T, specs []spec, surface, backend string) spec {
	t.Helper()
	for _, s := range specs {
		if s.surface == surface && s.backend == backend {
			return s
		}
	}
	t.Fatalf("spec %s/%s not found", surface, backend)
	return spec{}
}

func TestBuildSpecsRequiredGating(t *testing.T) {
	cfg := config.Defaults()
	cfg.Backend = "ddg"
	specs := buildSpecs(&cfg, http.DefaultClient)

	if s := findSpec(t, specs, "search", "ddg"); !s.required {
		t.Error("default search backend must be required")
	}
	if s := findSpec(t, specs, "search", "keenable"); s.required {
		t.Error("keenable without a key and not default must be informational")
	}
	if s := findSpec(t, specs, "search", "firecrawl"); s.required {
		t.Error("firecrawl without a key and not default must be informational")
	}
	if s := findSpec(t, specs, "search", "parallel"); s.required {
		t.Error("parallel not default must be informational")
	}
	if s := findSpec(t, specs, "code", "grepapp"); !s.required {
		t.Error("default code backend must be required")
	}
	if s := findSpec(t, specs, "code", "github"); s.required {
		t.Error("github not default must be informational")
	}
	if s := findSpec(t, specs, "docs", "search"); !s.required {
		t.Error("default docs backend must be required")
	}
	if s := findSpec(t, specs, "cache", "bbolt"); !s.required {
		t.Error("cache must always be required")
	}
	if s := findSpec(t, specs, "tags", "bbolt"); s.required {
		t.Error("the tag index is optional and must never gate the exit code")
	}
	if s := findSpec(t, specs, "browser", "none"); s.required {
		t.Error("unconfigured browser must not gate the exit code")
	}
}

func TestBuildSpecsParallelDefaultIsRequired(t *testing.T) {
	cfg := config.Defaults()
	cfg.Backend = "parallel"
	if candidate := findSpec(t, buildSpecs(&cfg, http.DefaultClient), "search", "parallel"); !candidate.required {
		t.Error("parallel must be required when configured as the default")
	}
}

func TestProbeKeyPoolChecksEveryKeyAndRejectsPool(t *testing.T) {
	keys := []string{"accepted-secret", "rejected-secret", "rate-limited-secret"}
	var mu sync.Mutex
	var probed []string
	status, detail := probeKeyPool(keys, func(key string) (Status, string) {
		mu.Lock()
		probed = append(probed, key)
		mu.Unlock()
		if key == "rejected-secret" {
			return StatusMisconfigured, "API key rejected"
		}
		return StatusOK, ""
	})
	if status != StatusMisconfigured {
		t.Fatalf("status = %q, want misconfigured", status)
	}
	if len(probed) != len(keys) {
		t.Fatalf("probed %d keys, want %d", len(probed), len(keys))
	}
	if !strings.Contains(detail, "key 2 of 3") {
		t.Fatalf("detail = %q, want rejected key ordinal", detail)
	}
	for _, key := range keys {
		if strings.Contains(detail, key) {
			t.Fatalf("detail exposed key %q: %s", key, detail)
		}
	}
}

func TestBuildSpecsPluralKeyedBackendIsRequired(t *testing.T) {
	cfg := config.Defaults()
	cfg.Backend = "ddg"
	cfg.SetProvider("firecrawl_api_keys", []string{"plural-only"})
	specs := buildSpecs(&cfg, http.DefaultClient)
	if candidate := findSpec(t, specs, "search", "firecrawl"); !candidate.required {
		t.Error("firecrawl with only a plural key must be required")
	}
}

func TestBuildSpecsKeyedBackendIsRequired(t *testing.T) {
	cfg := config.Defaults()
	cfg.Backend = "ddg"
	{
		providerValue0 := "k"
		cfg.SetProvider("firecrawl_api_key", // explicitly configured, so a broken Firecrawl should gate
			providerValue0)
	}
	cfg.Browser = "chrome"
	specs := buildSpecs(&cfg, http.DefaultClient)

	if s := findSpec(t, specs, "search", "firecrawl"); !s.required {
		t.Error("firecrawl with an explicit key must be required even when not default")
	}
	if s := findSpec(t, specs, "browser", "chrome"); !s.required {
		t.Error("configured browser must be required")
	}
}

func TestCheckBad(t *testing.T) {
	for status, want := range map[Status]bool{
		StatusOK:            false,
		StatusSkipped:       false,
		StatusNoKey:         true,
		StatusUnreachable:   true,
		StatusMisconfigured: true,
	} {
		if got := (Check{Status: status}).Bad(); got != want {
			t.Errorf("Bad(%q) = %v, want %v", status, got, want)
		}
	}
}

// A fallback chain does its job as long as one provider answers, so doctor
// must not fail a zero-config install because five of six keyless providers
// are rate-limited.
func TestAutoChainCheckIsHealthyWhenAnyProviderAnswers(t *testing.T) {
	checks := []Check{
		{Surface: "search", Backend: "parallel", Status: StatusUnreachable},
		{Surface: "search", Backend: "keenable", Status: StatusOK},
		{Surface: "search", Backend: "ddg", Status: StatusUnreachable},
	}
	status, detail := summarizeAutoChain([]string{"parallel", "keenable", "ddg"}, checks)
	if status != StatusOK {
		t.Fatalf("status = %q, want ok", status)
	}
	// The detail has to name the provider that would actually serve; "healthy"
	// alone hides an install limping on its last fallback.
	for _, want := range []string{"keenable serving", "1 of 3", "parallel → keenable → ddg"} {
		if !strings.Contains(detail, want) {
			t.Errorf("detail = %q, want it to contain %q", detail, want)
		}
	}
}

func TestAutoChainCheckFailsWhenNoProviderAnswers(t *testing.T) {
	checks := []Check{
		{Surface: "search", Backend: "parallel", Status: StatusUnreachable},
		{Surface: "search", Backend: "ddg", Status: StatusMisconfigured},
	}
	status, detail := summarizeAutoChain([]string{"parallel", "ddg"}, checks)
	if status != StatusUnreachable {
		t.Fatalf("status = %q, want unreachable", status)
	}
	if !strings.Contains(detail, "parallel → ddg") {
		t.Errorf("detail = %q, want it to name the chain", detail)
	}
}

func TestAutoChainCheckReportsAnEmptyChain(t *testing.T) {
	if status, _ := summarizeAutoChain(nil, nil); status != StatusMisconfigured {
		t.Fatalf("status = %q, want misconfigured for an empty chain", status)
	}
}

// Only a search check of the same name counts: a code backend that happens to
// share a provider name must not vouch for the search chain.
func TestAutoChainCheckIgnoresOtherSurfaces(t *testing.T) {
	checks := []Check{
		{Surface: "code", Backend: "parallel", Status: StatusOK},
		{Surface: "search", Backend: "parallel", Status: StatusUnreachable},
	}
	if status, _ := summarizeAutoChain([]string{"parallel"}, checks); status != StatusUnreachable {
		t.Fatalf("status = %q, want unreachable", status)
	}
}

// The synthesized row leads the report and gates the exit code, and only
// appears when auto is the configured backend.
func TestWithAutoChainCheckOnlyAppliesToTheAutoBackend(t *testing.T) {
	cfg := config.Defaults()
	checks := []Check{{Surface: "search", Backend: "parallel", Status: StatusOK}}

	got := withAutoChainCheck(&cfg, checks)
	if len(got) != len(checks)+1 {
		t.Fatalf("len(checks) = %d, want one synthesized row added", len(got))
	}
	if got[0].Backend != search.AutoBackend || got[0].Surface != "search" || !got[0].Required {
		t.Fatalf("first check = %+v, want a required search/auto row", got[0])
	}

	cfg.Backend = "ddg"
	if got := withAutoChainCheck(&cfg, checks); len(got) != len(checks) {
		t.Fatalf("len(checks) = %d, want no synthesized row for an explicit backend", len(got))
	}
}

// doctor reports the chain the operator pinned with search_order, in their
// order, and says so when nothing in it is usable.
func TestWithAutoChainCheckFollowsSearchOrder(t *testing.T) {
	cfg := config.Defaults()
	cfg.SearchOrder = []string{"ddg", "parallel"}
	checks := []Check{
		{Surface: "search", Backend: "parallel", Status: StatusOK},
		{Surface: "search", Backend: "ddg", Status: StatusOK},
	}
	got := withAutoChainCheck(&cfg, checks)
	if !strings.HasPrefix(got[0].Detail, "ddg serving") || !strings.Contains(got[0].Detail, "ddg → parallel") {
		t.Fatalf("detail = %q, want ddg serving over ddg → parallel", got[0].Detail)
	}

	cfg.SearchOrder = []string{"auto"}
	got = withAutoChainCheck(&cfg, checks)
	if got[0].Status != StatusMisconfigured || !strings.Contains(got[0].Detail, "invalid search_order") {
		t.Fatalf("auto row = %+v, want misconfigured invalid search_order", got[0])
	}
}
