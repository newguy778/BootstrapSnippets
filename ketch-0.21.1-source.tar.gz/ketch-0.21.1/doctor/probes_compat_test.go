package doctor

import (
	"github.com/1broseidon/ketch/code"
	"github.com/1broseidon/ketch/docs"
	"github.com/1broseidon/ketch/health"
	"github.com/1broseidon/ketch/search"
)

var probeDDG = search.ProbeDDG
var probeFirecrawl = search.ProbeFirecrawl
var probeKeenable = search.ProbeKeenable
var probeGitHub = code.ProbeGitHub
var probeContext7 = docs.ProbeContext7

var probeKeyPool = health.ProbeKeyPool
var probeMCP = health.ProbeMCP
var probeReachable = health.ProbeReachable
