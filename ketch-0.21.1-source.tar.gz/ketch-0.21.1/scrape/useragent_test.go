package scrape

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/1broseidon/ketch/config"
	"github.com/1broseidon/ketch/httpx"
)

func TestDefaultUserAgentIsDesktopChromeOnMac(t *testing.T) {
	t.Parallel()

	ua := DefaultUserAgent()
	for _, want := range []string{
		"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
		"AppleWebKit/537.36 (KHTML, like Gecko)",
		"Chrome/",
		"Safari/537.36",
	} {
		if !strings.Contains(ua, want) {
			t.Fatalf("DefaultUserAgent = %q, want it to contain %q", ua, want)
		}
	}
	if strings.Contains(ua, "ketch/") || strings.Contains(ua, "Headless") {
		t.Fatalf("DefaultUserAgent = %q, want no ketch or Headless marker", ua)
	}
	if ua != httpx.DefaultUserAgent {
		t.Fatalf("DefaultUserAgent = %q, want httpx.DefaultUserAgent %q", ua, httpx.DefaultUserAgent)
	}
}

func TestFetchSendsConfiguredUserAgent(t *testing.T) {
	t.Parallel()

	var got string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		got = r.Header.Get("User-Agent")
		_, _ = w.Write([]byte("<html><body><p>hi</p></body></html>"))
	}))
	t.Cleanup(srv.Close)

	s, err := NewFromConfig(&config.Config{UserAgent: "ketch-test/1 (+https://example.com)"})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(s.Close)

	if _, err := s.FetchContent(t.Context(), srv.URL); err != nil {
		t.Fatalf("FetchContent: %v", err)
	}
	if got != "ketch-test/1 (+https://example.com)" {
		t.Fatalf("User-Agent = %q, want configured override", got)
	}
}

func TestFetchSendsDefaultUserAgentWhenUnset(t *testing.T) {
	t.Parallel()

	var got string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		got = r.Header.Get("User-Agent")
		_, _ = w.Write([]byte("<html><body><p>hi</p></body></html>"))
	}))
	t.Cleanup(srv.Close)

	s := New()
	if _, err := s.FetchContent(t.Context(), srv.URL); err != nil {
		t.Fatalf("FetchContent: %v", err)
	}
	if got != DefaultUserAgent() {
		t.Fatalf("User-Agent = %q, want %q", got, DefaultUserAgent())
	}
}

func TestNewFromConfigRejectsControlCharactersInUserAgent(t *testing.T) {
	t.Parallel()

	_, err := NewFromConfig(&config.Config{UserAgent: "ketch/1\r\nX-Injected: 1"})
	if err == nil {
		t.Fatal("expected error for control characters")
	}
	if !strings.Contains(err.Error(), "user_agent") {
		t.Fatalf("error = %q, want user_agent mention", err)
	}
}

func TestNormalizeUserAgentEmptyFallsBackToDefault(t *testing.T) {
	t.Parallel()

	got, err := normalizeUserAgent("   ")
	if err != nil {
		t.Fatal(err)
	}
	if got != DefaultUserAgent() {
		t.Fatalf("normalizeUserAgent(blank) = %q, want %q", got, DefaultUserAgent())
	}
}

// A page fetch carries the browser's whole header set, not just the UA, so a
// fetch and a rendered page look alike to the site.
func TestFetchSendsBrowserHeaders(t *testing.T) {
	t.Parallel()

	var got http.Header
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		got = r.Header.Clone()
		_, _ = w.Write([]byte("<html><body><p>hi</p></body></html>"))
	}))
	defer srv.Close()

	s := New()
	if _, err := s.FetchContent(t.Context(), srv.URL); err != nil {
		t.Fatalf("FetchContent: %v", err)
	}
	for name, want := range map[string]string{
		"User-Agent":      DefaultUserAgent(),
		"Accept":          httpx.DocumentAccept,
		"Accept-Language": httpx.DefaultAcceptLanguage,
		"Sec-Fetch-Mode":  "navigate",
		"Sec-Fetch-Dest":  "document",
		"Sec-Fetch-Site":  "none",
		"Sec-Fetch-User":  "?1",
	} {
		if got.Get(name) != want {
			t.Errorf("%s = %q, want %q", name, got.Get(name), want)
		}
	}
}
