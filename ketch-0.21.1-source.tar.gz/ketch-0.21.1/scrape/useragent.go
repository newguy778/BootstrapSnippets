package scrape

import (
	"fmt"
	"strings"

	"github.com/1broseidon/ketch/httpx"
)

// DefaultUserAgent is the User-Agent ketch sends when no operator override is
// configured: a current desktop Chrome on macOS (httpx.DefaultUserAgent), the
// same string every other request path sends. A URL fetched over HTTP and one
// rendered in the headless browser therefore present as one client.
func DefaultUserAgent() string {
	return httpx.DefaultUserAgent
}

// normalizeUserAgent returns the User-Agent to send. Empty/whitespace means
// the built-in default. Control characters are rejected — they cannot appear
// in an HTTP header value and usually indicate a mistaken paste.
func normalizeUserAgent(ua string) (string, error) {
	ua = strings.TrimSpace(ua)
	if ua == "" {
		return DefaultUserAgent(), nil
	}
	if strings.ContainsAny(ua, "\r\n\x00") {
		return "", fmt.Errorf("user_agent must not contain control characters")
	}
	return ua, nil
}
