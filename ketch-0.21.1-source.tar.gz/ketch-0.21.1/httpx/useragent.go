package httpx

import (
	"fmt"
	"net/http"
	"strings"
	"sync/atomic"
)

// chromeMajor is the Chrome build the browser presentation claims: the
// User-Agent, the Sec-CH-UA brand list and the client-hint metadata the
// headless browser is launched with all read it, so a bump is one edit.
const chromeMajor = "157"

// DefaultUserAgent is the User-Agent ketch sends for every HTTP request whose
// caller has not set one, and the base of the operator override: the string a
// current desktop Chrome on macOS sends.
const DefaultUserAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + chromeMajor + ".0.0.0 Safari/537.36"

// The rest of what that browser sends. They travel together: a Sec-CH-UA list
// naming a different platform or version than the User-Agent is itself a bot
// signal, so the transport only sends them for DefaultUserAgent.
const (
	// DefaultAcceptLanguage is the Accept-Language header of a Chrome
	// installed in the default en-US locale.
	DefaultAcceptLanguage = "en-US,en;q=0.9"
	// DefaultLanguages is the same list as the browser's language emulation
	// takes it: weights are Chromium's to add, so sending them here would
	// double them ("en-US,en;q=0.9;q=0.9").
	DefaultLanguages = "en-US,en"
	// DefaultPlatform is the Sec-CH-UA-Platform token.
	DefaultPlatform = "macOS"
	// DefaultPlatformVersion is what macOS reports through the client hints.
	DefaultPlatformVersion = "15.0.0"
	// DefaultArchitecture and DefaultBitness fill the client-hint metadata.
	DefaultArchitecture = "x86"
	DefaultBitness      = "64"
	// DefaultNavigatorPlatform is navigator.platform on a Mac: the Intel value,
	// which Chrome keeps reporting under emulation too.
	DefaultNavigatorPlatform = "MacIntel"
	// DefaultMobile is the Sec-CH-UA-Mobile flag.
	DefaultMobile = "?0"
	// DocumentAccept is what Chrome sends for a top-level navigation. The
	// application/pdf entry is kept so a URL that negotiates a PDF still gets
	// one; Chrome sends its document Accept there too.
	DocumentAccept = "text/html,application/xhtml+xml,application/xml;q=0.9,application/pdf;q=0.9,image/avif,image/webp,*/*;q=0.8"
)

// BrandVersion is one entry of the Sec-CH-UA brand list.
type BrandVersion struct {
	Brand   string
	Version string
}

// ChromeBrands returns the Sec-CH-UA brands that match DefaultUserAgent, in
// the order Chrome reports them (the GREASE entry first).
func ChromeBrands() []BrandVersion {
	return []BrandVersion{
		{Brand: "Not_A Brand", Version: "24"},
		{Brand: "Chromium", Version: chromeMajor},
		{Brand: "Google Chrome", Version: chromeMajor},
	}
}

// SecChUA renders ChromeBrands as the Sec-CH-UA header value.
func SecChUA() string {
	brands := ChromeBrands()
	parts := make([]string, len(brands))
	for i, b := range brands {
		parts[i] = fmt.Sprintf("%q;v=%q", b.Brand, b.Version)
	}
	return strings.Join(parts, ", ")
}

// userAgent holds the process-wide User-Agent: DefaultUserAgent until the
// surfaces set it from the loaded config. Stored as a string (never nil).
var userAgent atomic.Value

func init() { userAgent.Store(DefaultUserAgent) }

// SetUserAgent sets the User-Agent every client fills in for requests that
// carry none. Blank (or whitespace) restores DefaultUserAgent. cmd and the MCP
// server call it once from the loaded config, before any request; a caller
// that leaves it alone gets the default.
//
// A configured value that is not DefaultUserAgent is sent as given, without the
// Chrome client hints: those describe a browser, and a custom User-Agent may
// be anything.
func SetUserAgent(ua string) { userAgent.Store(ResolveUserAgent(ua)) }

// UserAgent returns the User-Agent a request without its own header is sent
// with.
func UserAgent() string { return userAgent.Load().(string) }

// ResolveUserAgent returns configured, trimmed, or DefaultUserAgent when it is
// blank.
func ResolveUserAgent(configured string) string {
	if ua := strings.TrimSpace(configured); ua != "" {
		return ua
	}
	return DefaultUserAgent
}

// BrowserHeaders returns the header set a desktop Chrome sends alongside ua,
// for a top-level navigation (GET) or a scripted request (anything else), and
// nil when ua is not the built-in browser User-Agent. secure says the request
// is https: Chrome sends the Sec-CH-UA client hints only to secure origins,
// so an http request that carried them would be the one thing a browser never
// sends. Callers that fill them in must leave a header the request already
// carries alone.
func BrowserHeaders(method string, secure bool, ua string) [][2]string {
	if ua != DefaultUserAgent {
		return nil
	}
	nav := method == http.MethodGet || method == http.MethodHead
	headers := [][2]string{{"Accept-Language", DefaultAcceptLanguage}}
	if secure {
		headers = append(headers,
			[2]string{"Sec-Ch-Ua", SecChUA()},
			[2]string{"Sec-Ch-Ua-Mobile", DefaultMobile},
			[2]string{"Sec-Ch-Ua-Platform", `"` + DefaultPlatform + `"`},
		)
	}
	if nav {
		return append(headers,
			[2]string{"Sec-Fetch-Site", "none"},
			[2]string{"Sec-Fetch-Mode", "navigate"},
			[2]string{"Sec-Fetch-User", "?1"},
			[2]string{"Sec-Fetch-Dest", "document"},
			[2]string{"Upgrade-Insecure-Requests", "1"},
		)
	}
	return append(headers,
		[2]string{"Sec-Fetch-Site", "same-origin"},
		[2]string{"Sec-Fetch-Mode", "cors"},
		[2]string{"Sec-Fetch-Dest", "empty"},
	)
}

// userAgentTransport fills in the User-Agent and, for the built-in browser
// User-Agent, the rest of Chrome's header set on requests that carry none,
// reading the process-wide value per request so SetUserAgent reaches clients
// built before it ran. A request that sets its own header keeps it, so a
// provider's own Accept or User-Agent wins.
type userAgentTransport struct {
	base http.RoundTripper
}

func (t userAgentTransport) RoundTrip(req *http.Request) (*http.Response, error) {
	ua := req.Header.Get("User-Agent")
	fillUA := ua == ""
	if fillUA {
		ua = UserAgent()
	}
	extra := BrowserHeaders(req.Method, req.URL != nil && req.URL.Scheme == "https", ua)
	if !fillUA && len(extra) == 0 {
		return t.base.RoundTrip(req)
	}

	clone := req.Clone(req.Context())
	if fillUA {
		clone.Header.Set("User-Agent", ua)
	}
	for _, h := range extra {
		if clone.Header.Get(h[0]) == "" {
			clone.Header.Set(h[0], h[1])
		}
	}
	return t.base.RoundTrip(clone)
}
