package httpx

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

// resetUserAgent restores the process default after a test that changes it, so
// parallel tests in other packages never inherit a custom value.
func resetUserAgent(t *testing.T) {
	t.Helper()
	t.Cleanup(func() { SetUserAgent("") })
}

func TestUserAgentDefaultsToDesktopChrome(t *testing.T) {
	ua := UserAgent()
	if ua != DefaultUserAgent {
		t.Fatalf("UserAgent() = %q, want DefaultUserAgent %q", ua, DefaultUserAgent)
	}
	if !strings.Contains(ua, "Macintosh; Intel Mac OS X 10_15_7") || !strings.Contains(ua, "Chrome/157.0.0.0") || !strings.Contains(ua, "Safari/537.36") {
		t.Fatalf("DefaultUserAgent = %q, want the macOS Chrome shape", ua)
	}
	if got := ResolveUserAgent("  "); got != DefaultUserAgent {
		t.Fatalf("ResolveUserAgent(blank) = %q, want %q", got, DefaultUserAgent)
	}
	if got := ResolveUserAgent("  custom/1.2 "); got != "custom/1.2" {
		t.Fatalf("ResolveUserAgent(custom) = %q, want trimmed custom/1.2", got)
	}
}

func TestSetUserAgentFillsRequestsWithoutOne(t *testing.T) {
	resetUserAgent(t)

	var got string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		got = r.Header.Get("User-Agent")
	}))
	defer srv.Close()

	client := New(0, DefaultMaxIdleConnsPerHost)

	SetUserAgent("operator/9.9")
	if _, err := client.Get(srv.URL); err != nil {
		t.Fatalf("GET: %v", err)
	}
	if got != "operator/9.9" {
		t.Fatalf("User-Agent = %q, want the configured value", got)
	}

	// Blank restores the built-in default.
	SetUserAgent("   ")
	if _, err := client.Get(srv.URL); err != nil {
		t.Fatalf("GET: %v", err)
	}
	if got != DefaultUserAgent {
		t.Fatalf("User-Agent = %q, want the default %q", got, DefaultUserAgent)
	}
}

func TestRequestUserAgentWins(t *testing.T) {
	resetUserAgent(t)
	SetUserAgent("operator/9.9")

	var got string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		got = r.Header.Get("User-Agent")
	}))
	defer srv.Close()

	req, err := http.NewRequest(http.MethodGet, srv.URL, nil)
	if err != nil {
		t.Fatal(err)
	}
	req.Header.Set("User-Agent", "per-request/1.0")
	if _, err := New(0, DefaultMaxIdleConnsPerHost).Do(req); err != nil {
		t.Fatalf("GET: %v", err)
	}
	if got != "per-request/1.0" {
		t.Fatalf("User-Agent = %q, want the request's own value", got)
	}
}

// A request Chrome would make carries Chrome's whole header set, not just the
// UA: navigations and scripted requests differ exactly as a browser's do.
func TestBrowserHeadersMatchTheUserAgent(t *testing.T) {
	var got http.Header
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		got = r.Header.Clone()
	}))
	defer srv.Close()

	client := New(0, DefaultMaxIdleConnsPerHost)

	if _, err := client.Get(srv.URL); err != nil {
		t.Fatalf("GET: %v", err)
	}
	// http is not a secure origin: Chrome sends no client hints there, so the
	// request that carries them would be the odd one out.
	want := map[string]string{
		"User-Agent":                DefaultUserAgent,
		"Accept-Language":           DefaultAcceptLanguage,
		"Sec-Fetch-Site":            "none",
		"Sec-Fetch-Mode":            "navigate",
		"Sec-Fetch-User":            "?1",
		"Sec-Fetch-Dest":            "document",
		"Upgrade-Insecure-Requests": "1",
	}
	for name, value := range want {
		if got.Get(name) != value {
			t.Errorf("GET %s = %q, want %q", name, got.Get(name), value)
		}
	}
	for _, name := range []string{"Sec-Ch-Ua", "Sec-Ch-Ua-Mobile", "Sec-Ch-Ua-Platform"} {
		if v := got.Get(name); v != "" {
			t.Errorf("GET over http sent %s = %q, want none outside a secure origin", name, v)
		}
	}

	if _, err := client.Post(srv.URL, "application/json", strings.NewReader("{}")); err != nil {
		t.Fatalf("POST: %v", err)
	}
	cors := map[string]string{
		"Sec-Fetch-Site": "same-origin",
		"Sec-Fetch-Mode": "cors",
		"Sec-Fetch-Dest": "empty",
	}
	for name, value := range cors {
		if got.Get(name) != value {
			t.Errorf("POST %s = %q, want %q", name, got.Get(name), value)
		}
	}
	if got.Get("Sec-Fetch-User") != "" || got.Get("Upgrade-Insecure-Requests") != "" {
		t.Errorf("POST carried navigation-only headers: %v", got)
	}
}

// The brand list the header advertises is the browser build the UA names.
func TestSecChUANamesTheUserAgentVersion(t *testing.T) {
	ua := DefaultUserAgent
	header := SecChUA()
	major := ua[strings.Index(ua, "Chrome/")+len("Chrome/"):]
	major, _, _ = strings.Cut(major, ".")
	if !strings.Contains(header, `"Google Chrome";v="`+major+`"`) {
		t.Fatalf("Sec-CH-UA = %q, want Google Chrome v=%s from %q", header, major, ua)
	}
	for _, brand := range ChromeBrands() {
		if !strings.Contains(header, `"`+brand.Brand+`";v="`+brand.Version+`"`) {
			t.Fatalf("Sec-CH-UA = %q, missing brand %v", header, brand)
		}
	}
}

// A custom User-Agent is not a browser ketch can describe, so no Chrome
// client hints ride along; explicit headers still win over the default set.
func TestCustomUserAgentSuppressesBrowserHeaders(t *testing.T) {
	resetUserAgent(t)
	SetUserAgent("acme-bot/1.0 (+https://example.com)")

	var got http.Header
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		got = r.Header.Clone()
	}))
	defer srv.Close()

	req, err := http.NewRequest(http.MethodGet, srv.URL, nil)
	if err != nil {
		t.Fatal(err)
	}
	req.Header.Set("Accept-Language", "de-DE,de;q=0.9")
	if _, err := New(0, DefaultMaxIdleConnsPerHost).Do(req); err != nil {
		t.Fatalf("GET: %v", err)
	}
	if got.Get("User-Agent") != "acme-bot/1.0 (+https://example.com)" {
		t.Errorf("User-Agent = %q, want the configured one", got.Get("User-Agent"))
	}
	for _, name := range []string{"Sec-Ch-Ua", "Sec-Fetch-Mode", "Sec-Fetch-Site", "Upgrade-Insecure-Requests"} {
		if v := got.Get(name); v != "" {
			t.Errorf("%s = %q, want none for a custom UA", name, v)
		}
	}
	if got.Get("Accept-Language") != "de-DE,de;q=0.9" {
		t.Errorf("Accept-Language = %q, want the request's own value", got.Get("Accept-Language"))
	}
}

// The client hints are secure-origin only, exactly as Chrome sends them.
func TestBrowserHeadersSecureOrigin(t *testing.T) {
	nav := map[string]string{}
	for _, h := range BrowserHeaders(http.MethodGet, true, DefaultUserAgent) {
		nav[h[0]] = h[1]
	}
	for name, want := range map[string]string{
		"Sec-Ch-Ua":          SecChUA(),
		"Sec-Ch-Ua-Mobile":   DefaultMobile,
		"Sec-Ch-Ua-Platform": `"macOS"`,
		"Sec-Fetch-Mode":     "navigate",
	} {
		if nav[name] != want {
			t.Errorf("https GET %s = %q, want %q", name, nav[name], want)
		}
	}
	if got := BrowserHeaders(http.MethodGet, false, "custom/1.0"); got != nil {
		t.Fatalf("custom UA headers = %v, want none", got)
	}
	if got := BrowserHeaders(http.MethodGet, true, "custom/1.0"); got != nil {
		t.Fatalf("custom UA headers = %v, want none", got)
	}
}

// Over https the same request carries Chrome's client hints, which is what
// makes the UA and the hints agree instead of contradicting each other.
func TestBrowserHeadersOverTLS(t *testing.T) {
	resetUserAgent(t)

	var got http.Header
	srv := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		got = r.Header.Clone()
	}))
	defer srv.Close()

	// The test server's client trusts its certificate; keep that transport and
	// wrap it the way New wraps a real one.
	client := &http.Client{Transport: userAgentTransport{srv.Client().Transport}}
	if _, err := client.Get(srv.URL); err != nil {
		t.Fatalf("GET: %v", err)
	}
	for name, want := range map[string]string{
		"Sec-Ch-Ua":          SecChUA(),
		"Sec-Ch-Ua-Mobile":   DefaultMobile,
		"Sec-Ch-Ua-Platform": `"macOS"`,
		"Sec-Fetch-Mode":     "navigate",
		"Accept-Language":    DefaultAcceptLanguage,
	} {
		if got.Get(name) != want {
			t.Errorf("https GET %s = %q, want %q", name, got.Get(name), want)
		}
	}
}
