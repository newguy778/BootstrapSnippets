package cmd

import (
	"bytes"
	"encoding/json"
	"errors"
	"io"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	"github.com/1broseidon/ketch/config"
	"github.com/1broseidon/ketch/internal/testutil"
	"github.com/1broseidon/ketch/scrape"
)

func TestApplyConfigSetAPIKeysRoundTrip(t *testing.T) {
	cfg := config.Defaults()
	if err := applyConfigSet(&cfg, "parallel_api_keys", `["k1","k2"]`); err != nil {
		t.Fatal(err)
	}
	data, err := json.Marshal(cfg)
	if err != nil {
		t.Fatal(err)
	}
	var loaded config.Config
	if err := json.Unmarshal(data, &loaded); err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(loaded.Strings("parallel_api_keys"), []string{"k1", "k2"}) {
		t.Fatalf("round-tripped keys = %v", loaded.Strings("parallel_api_keys"))
	}
}

func TestApplyConfigSetAPIKeysInvalid(t *testing.T) {
	for _, value := range []string{`not-json`, `null`, `{"key":"value"}`} {
		t.Run(value, func(t *testing.T) {
			cfg := config.Defaults()
			cfg.SetProvider("parallel_api_keys", []string{"existing"})
			if err := applyConfigSet(&cfg, "parallel_api_keys", value); err == nil {
				t.Fatal("expected JSON array validation error")
			}
			if !reflect.DeepEqual(cfg.Strings("parallel_api_keys"), []string{"existing"}) {
				t.Fatalf("invalid input modified keys: %v", cfg.Strings("parallel_api_keys"))
			}
		})
	}
}

func TestApplyConfigSetAPIKeysEmptyClears(t *testing.T) {
	cfg := config.Defaults()
	cfg.SetProvider("parallel_api_keys", []string{"existing"})
	if err := applyConfigSet(&cfg, "parallel_api_keys", `[]`); err != nil {
		t.Fatal(err)
	}
	if len(cfg.Strings("parallel_api_keys")) != 0 {
		t.Fatalf("keys = %v, want empty", cfg.Strings("parallel_api_keys"))
	}
}

func TestBuildConfigInfoReportsEffectiveKeyCountsWithoutValues(t *testing.T) {
	cfg := config.Defaults()
	cfg.SetProvider("parallel_api_key", "singular-secret")
	cfg.SetProvider("parallel_api_keys", []string{"plural-secret", "singular-secret"})
	info := buildConfigInfo(cfg, "/tmp/config.json")
	if info.Providers["parallel_api_key_set"] != true || info.Providers["parallel_api_keys_count"] != 2 {
		t.Fatalf("key discovery = set:%v count:%d", info.Providers["parallel_api_key_set"], info.Providers["parallel_api_keys_count"])
	}
	data, err := json.Marshal(info)
	if err != nil {
		t.Fatal(err)
	}
	for _, secret := range []string{"singular-secret", "plural-secret"} {
		if strings.Contains(string(data), secret) {
			t.Fatal("config discovery exposed an API key value")
		}
	}
}

func TestConfigHTTPHeadersShowsNamesNotValues(t *testing.T) {
	cfg := config.Defaults()
	if err := applyConfigSet(&cfg, "http_headers", `{"https://searx.example":{"CF-Access-Client-Secret":"header-secret","CF-Access-Client-Id":"id-secret"}}`); err != nil {
		t.Fatal(err)
	}
	data, err := json.Marshal(buildConfigInfo(cfg, "/tmp/config.json"))
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(string(data), "header-secret") || strings.Contains(string(data), "id-secret") {
		t.Fatal("config discovery printed a header value")
	}
	if !strings.Contains(string(data), `"http_header_names":{"https://searx.example":["CF-Access-Client-Id","CF-Access-Client-Secret"]}`) {
		t.Fatalf("config discovery = %s, want header names per origin", data)
	}
}

func TestConfigSetHTTPHeadersRejectsInvalidValues(t *testing.T) {
	for _, value := range []string{
		`{"https://searx.example":{"X-A":["header-secret"]}}`,
		`{"https://searx.example/search":{"X-A":"header-secret"}}`,
		`{"https://searx.example":{"X-A":"header-secret\r\nInjected: yes"}}`,
	} {
		cfg := config.Defaults()
		err := applyConfigSet(&cfg, "http_headers", value)
		var exitErr *ExitError
		if !errors.As(err, &exitErr) || exitErr.Code != ExitValidation {
			t.Fatalf("%s: error = %v, want exit %d", value, err, ExitValidation)
		}
		if strings.Contains(err.Error(), "header-secret") {
			t.Fatalf("error echoed a header value: %v", err)
		}
	}
}

func TestRunConfigSetNeverEchoesSecrets(t *testing.T) {
	tests := []struct {
		key     string
		value   string
		secrets []string
		want    string
	}{
		{key: "parallel_api_key", value: "parallel-secret", secrets: []string{"parallel-secret"}, want: "set parallel_api_key (1 key)\n"},
		{key: "parallel_api_keys", value: `["parallel-one","parallel-two"]`, secrets: []string{"parallel-one", "parallel-two"}, want: "set parallel_api_keys (2 keys)\n"},
		{key: "firecrawl_api_key", value: "firecrawl-secret", secrets: []string{"firecrawl-secret"}, want: "set firecrawl_api_key (1 key)\n"},
		{key: "firecrawl_api_keys", value: `["firecrawl-one","firecrawl-two"]`, secrets: []string{"firecrawl-one", "firecrawl-two"}, want: "set firecrawl_api_keys (2 keys)\n"},
		{key: "keenable_api_key", value: "keenable-secret", secrets: []string{"keenable-secret"}, want: "set keenable_api_key (1 key)\n"},
		{key: "keenable_api_keys", value: `["keenable-one","keenable-two"]`, secrets: []string{"keenable-one", "keenable-two"}, want: "set keenable_api_keys (2 keys)\n"},
		{key: "context7_api_key", value: "context7-secret", secrets: []string{"context7-secret"}, want: "set context7_api_key (1 key)\n"},
		{key: "github_token", value: "github-secret", secrets: []string{"github-secret"}, want: "set github_token (1 token)\n"},
		{key: "http_headers", value: `{"https://searx.example":{"CF-Access-Client-Secret":"header-secret"}}`, secrets: []string{"header-secret"}, want: "set http_headers (1 origin)\n"},
	}

	for _, test := range tests {
		t.Run(test.key, func(t *testing.T) {
			testutil.SetIsolatedConfigHome(t)
			output, err := captureStderr(t, func() error {
				return runConfigSet(nil, []string{test.key, test.value})
			})
			if err != nil {
				t.Fatal(err)
			}
			if output != test.want {
				t.Fatal("config set emitted an unexpected acknowledgement")
			}
			for _, secret := range test.secrets {
				if strings.Contains(output, secret) {
					t.Fatal("config set echoed a secret value")
				}
			}
		})
	}
}

func TestRunConfigSetRefusesUndecodableFile(t *testing.T) {
	path := filepath.Join(testutil.SetIsolatedConfigHome(t), "config.json")
	t.Setenv("KETCH_CONFIG", path)
	original := []byte(`{"firecrawl_url":"https://private.example","limit":"7"}`)
	if err := os.WriteFile(path, original, 0o600); err != nil {
		t.Fatal(err)
	}

	err := runConfigSet(nil, []string{"backend", "firecrawl"})
	var exitErr *ExitError
	if !errors.As(err, &exitErr) || exitErr.Code != ExitValidation {
		t.Fatalf("error = %v, want exit %d", err, ExitValidation)
	}
	if !strings.HasPrefix(err.Error(), "invalid configuration:") || !strings.Contains(err.Error(), "limit must be a whole number") {
		t.Fatalf("error = %q, want an invalid configuration naming limit", err)
	}
	got, readErr := os.ReadFile(path)
	if readErr != nil {
		t.Fatal(readErr)
	}
	if !bytes.Equal(got, original) {
		t.Fatalf("config set rewrote an undecodable file: %s", got)
	}
}

func TestConfigSetAcknowledgementUsesEffectiveKeyCount(t *testing.T) {
	cfg := config.Defaults()
	cfg.SetProvider("parallel_api_key", "first")
	cfg.SetProvider("parallel_api_keys", []string{"first", "second", " "})
	if got := configSetAcknowledgement(cfg, "parallel_api_keys", "unused"); got != "set parallel_api_keys (2 keys)" {
		t.Fatalf("acknowledgement = %q, want effective de-duplicated count", got)
	}
}

func captureStderr(t *testing.T, fn func() error) (string, error) {
	t.Helper()
	reader, writer, err := os.Pipe()
	if err != nil {
		t.Fatal(err)
	}
	original := os.Stderr
	os.Stderr = writer
	callErr := fn()
	os.Stderr = original
	if err := writer.Close(); err != nil {
		t.Fatal(err)
	}
	data, err := io.ReadAll(reader)
	if err != nil {
		t.Fatal(err)
	}
	if err := reader.Close(); err != nil {
		t.Fatal(err)
	}
	return string(data), callErr
}

func TestApplyConfigSetURLRewritesValidJSON(t *testing.T) {
	c := config.Defaults()
	err := applyConfigSet(&c, "url_rewrites", `[{"match":"^https?://www\\.reddit\\.com/(.*)$","replace":"https://old.reddit.com/$1"}]`)
	if err != nil {
		t.Fatalf("unexpected err: %v", err)
	}
	if len(c.URLRewrites) != 1 {
		t.Fatalf("want 1 rule, got %d", len(c.URLRewrites))
	}
	if c.URLRewrites[0].Replace != "https://old.reddit.com/$1" {
		t.Errorf("Replace mismatch: %q", c.URLRewrites[0].Replace)
	}
}

func TestApplyConfigSetFirecrawlURL(t *testing.T) {
	c := config.Defaults()
	if err := applyConfigSet(&c, "firecrawl_url", "http://localhost:3002"); err != nil {
		t.Fatal(err)
	}
	if c.String("firecrawl_url") != "http://localhost:3002" {
		t.Fatalf("FirecrawlURL = %q", c.String("firecrawl_url"))
	}
	info := buildConfigInfo(c, "/tmp/config.json")
	if info.Providers["firecrawl_url"] != "http://localhost:3002" {
		t.Fatalf("discovery firecrawl_url = %q", info.Providers["firecrawl_url"])
	}
}

func TestApplyConfigSetURLRewritesInvalidJSON(t *testing.T) {
	c := config.Defaults()
	err := applyConfigSet(&c, "url_rewrites", `not json`)
	if err == nil {
		t.Fatalf("want JSON parse error")
	}
	if !strings.Contains(strings.ToLower(err.Error()), "json") {
		t.Errorf("error should mention JSON, got: %v", err)
	}
}

func TestApplyConfigSetURLRewritesInvalidRegex(t *testing.T) {
	c := config.Defaults()
	err := applyConfigSet(&c, "url_rewrites", `[{"match":"[","replace":"x"}]`)
	if err == nil {
		t.Fatalf("want regex compile error")
	}
}

func TestApplyConfigSetURLRewritesEmptyClears(t *testing.T) {
	c := config.Defaults()
	if err := applyConfigSet(&c, "url_rewrites", `[{"match":"^x$","replace":"y"}]`); err != nil {
		t.Fatalf("setup: %v", err)
	}
	if len(c.URLRewrites) != 1 {
		t.Fatalf("setup failed: %d rules", len(c.URLRewrites))
	}
	if err := applyConfigSet(&c, "url_rewrites", `[]`); err != nil {
		t.Fatalf("unexpected err: %v", err)
	}
	if len(c.URLRewrites) != 0 {
		t.Errorf("want empty list after [] reset, got %d rules", len(c.URLRewrites))
	}
}

func TestApplyConfigSetCookieFile(t *testing.T) {
	jar := filepath.Join(t.TempDir(), "cookies.txt")
	if err := os.WriteFile(jar, []byte("example.com\tTRUE\t/\tFALSE\t0\tsid\tv\n"), 0o600); err != nil {
		t.Fatal(err)
	}

	t.Run("valid jar sets field", func(t *testing.T) {
		c := config.Defaults()
		if err := applyConfigSet(&c, "cookie_file", jar); err != nil {
			t.Fatalf("unexpected err: %v", err)
		}
		if c.CookieFile != jar {
			t.Fatalf("CookieFile = %q, want %q", c.CookieFile, jar)
		}
	})

	t.Run("bad path is a validation error", func(t *testing.T) {
		c := config.Defaults()
		err := applyConfigSet(&c, "cookie_file", "/nonexistent/jar.txt")
		if err == nil {
			t.Fatal("expected validation error")
		}
		var exitErr *ExitError
		if !errors.As(err, &exitErr) || exitErr.Code != ExitValidation {
			t.Fatalf("error = %v, want exit %d", err, ExitValidation)
		}
		if c.CookieFile != "" {
			t.Fatalf("bad path changed config to %q", c.CookieFile)
		}
	})

	t.Run("empty clears", func(t *testing.T) {
		c := config.Defaults()
		c.CookieFile = jar
		if err := applyConfigSet(&c, "cookie_file", ""); err != nil {
			t.Fatalf("unexpected err: %v", err)
		}
		if c.CookieFile != "" {
			t.Fatalf("CookieFile = %q, want empty", c.CookieFile)
		}
	})
}

func TestBuildConfigInfoShowsCookieFilePathNoValues(t *testing.T) {
	c := config.Defaults()
	c.CookieFile = "/home/user/cookies.txt"
	info := buildConfigInfo(c, "/tmp/config.json")
	if info.CookieFile != c.CookieFile {
		t.Fatalf("CookieFile = %q, want %q", info.CookieFile, c.CookieFile)
	}
	data, err := json.Marshal(info)
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(string(data), "cookie_file") {
		t.Fatal("discovery payload should carry the cookie_file path")
	}
}

func TestApplyConfigSetUserAgent(t *testing.T) {
	t.Run("sets override", func(t *testing.T) {
		c := config.Defaults()
		if err := applyConfigSet(&c, "user_agent", "ketch-test/1 (+https://example.com)"); err != nil {
			t.Fatalf("unexpected err: %v", err)
		}
		if c.UserAgent != "ketch-test/1 (+https://example.com)" {
			t.Fatalf("UserAgent = %q", c.UserAgent)
		}
	})

	t.Run("rejects control characters", func(t *testing.T) {
		c := config.Defaults()
		err := applyConfigSet(&c, "user_agent", "ketch/1\nX-Injected: 1")
		if err == nil {
			t.Fatal("expected validation error")
		}
		var exitErr *ExitError
		if !errors.As(err, &exitErr) || exitErr.Code != ExitValidation {
			t.Fatalf("error = %v, want exit %d", err, ExitValidation)
		}
		if c.UserAgent != "" {
			t.Fatalf("bad value changed config to %q", c.UserAgent)
		}
	})

	t.Run("empty clears", func(t *testing.T) {
		c := config.Defaults()
		c.UserAgent = "custom/1"
		if err := applyConfigSet(&c, "user_agent", ""); err != nil {
			t.Fatalf("unexpected err: %v", err)
		}
		if c.UserAgent != "" {
			t.Fatalf("UserAgent = %q, want empty", c.UserAgent)
		}
	})
}

func TestBuildConfigInfoShowsEffectiveUserAgent(t *testing.T) {
	t.Run("default when unset", func(t *testing.T) {
		info := buildConfigInfo(config.Defaults(), "/tmp/config.json")
		if info.UserAgent != scrape.DefaultUserAgent() {
			t.Fatalf("UserAgent = %q, want %q", info.UserAgent, scrape.DefaultUserAgent())
		}
	})

	t.Run("override when set", func(t *testing.T) {
		c := config.Defaults()
		c.UserAgent = "custom/1"
		info := buildConfigInfo(c, "/tmp/config.json")
		if info.UserAgent != "custom/1" {
			t.Fatalf("UserAgent = %q, want custom/1", info.UserAgent)
		}
	})
}

func TestApplyConfigSetUnknownKey(t *testing.T) {
	c := config.Defaults()
	err := applyConfigSet(&c, "no_such_key", "x")
	if err == nil {
		t.Fatalf("want unknown-key error")
	}
}

func TestApplyConfigSetSPAMarkersValid(t *testing.T) {
	c := config.Defaults()
	err := applyConfigSet(&c, "spa_markers", `["__next_f","data-v-app"]`)
	if err != nil {
		t.Fatalf("unexpected err: %v", err)
	}
	if len(c.SPAMarkers) != 2 {
		t.Fatalf("want 2 markers, got %d", len(c.SPAMarkers))
	}
	if c.SPAMarkers[0] != "__next_f" || c.SPAMarkers[1] != "data-v-app" {
		t.Errorf("markers mismatch: %v", c.SPAMarkers)
	}
}

func TestApplyConfigSetSPAMarkersInvalidJSON(t *testing.T) {
	c := config.Defaults()
	err := applyConfigSet(&c, "spa_markers", `not json`)
	if err == nil {
		t.Fatalf("want JSON parse error")
	}
	if !strings.Contains(strings.ToLower(err.Error()), "json") {
		t.Errorf("error should mention JSON, got: %v", err)
	}
}

func TestApplyConfigSetSPAMarkersRejectsBlank(t *testing.T) {
	c := config.Defaults()
	err := applyConfigSet(&c, "spa_markers", `["__next_f","  "]`)
	if err == nil {
		t.Fatalf("want blank-marker error")
	}
}

func TestApplyConfigSetSPAMarkersEmptyClears(t *testing.T) {
	c := config.Defaults()
	if err := applyConfigSet(&c, "spa_markers", `["__next_f"]`); err != nil {
		t.Fatalf("setup: %v", err)
	}
	if len(c.SPAMarkers) != 1 {
		t.Fatalf("setup failed: %d markers", len(c.SPAMarkers))
	}
	if err := applyConfigSet(&c, "spa_markers", `[]`); err != nil {
		t.Fatalf("unexpected err: %v", err)
	}
	if len(c.SPAMarkers) != 0 {
		t.Errorf("want empty list after [] reset, got %d markers", len(c.SPAMarkers))
	}
}

func TestApplyConfigSetExternalPDFConverter(t *testing.T) {
	c := config.Defaults()
	if c.ExternalPDFToMDConverterTimeoutSec != 300 {
		t.Fatalf("default timeout = %d, want 300", c.ExternalPDFToMDConverterTimeoutSec)
	}
	if err := applyConfigSet(&c, "external_pdf_to_md_converter_command", "pdftotext {input} -"); err != nil {
		t.Fatalf("set command: %v", err)
	}
	if err := applyConfigSet(&c, "external_pdf_to_md_converter_timeout_sec", "45"); err != nil {
		t.Fatalf("set timeout: %v", err)
	}
	if c.ExternalPDFToMDConverterCommand != "pdftotext {input} -" || c.ExternalPDFToMDConverterTimeoutSec != 45 {
		t.Fatalf("config = %#v", c)
	}
}

func TestApplyConfigSetExternalPDFConverterRejectsInvalidCommand(t *testing.T) {
	for _, test := range []struct {
		name  string
		value string
	}{
		{name: "invalid shlex", value: `converter "{input}`},
		{name: "missing placeholder", value: "converter input.pdf"},
		{name: "duplicate placeholder", value: "converter {input} --again={input}"},
	} {
		t.Run(test.name, func(t *testing.T) {
			c := config.Defaults()
			c.ExternalPDFToMDConverterCommand = "existing {input}"
			err := applyConfigSet(&c, "external_pdf_to_md_converter_command", test.value)
			if err == nil {
				t.Fatal("expected validation error")
			}
			var exitErr *ExitError
			if !errors.As(err, &exitErr) || exitErr.Code != ExitValidation {
				t.Fatalf("error = %v, want exit %d", err, ExitValidation)
			}
			if c.ExternalPDFToMDConverterCommand != "existing {input}" {
				t.Fatalf("invalid value changed config to %q", c.ExternalPDFToMDConverterCommand)
			}
		})
	}
}

func TestApplyConfigSetExternalPDFConverterEmptyClears(t *testing.T) {
	c := config.Defaults()
	c.ExternalPDFToMDConverterCommand = "converter {input}"
	if err := applyConfigSet(&c, "external_pdf_to_md_converter_command", ""); err != nil {
		t.Fatalf("clear command: %v", err)
	}
	if c.ExternalPDFToMDConverterCommand != "" {
		t.Fatalf("command = %q, want empty", c.ExternalPDFToMDConverterCommand)
	}
}

func TestApplyConfigSetExternalPDFConverterRejectsInvalidTimeout(t *testing.T) {
	for _, value := range []string{"0", "-1", "not-an-int"} {
		t.Run(value, func(t *testing.T) {
			c := config.Defaults()
			err := applyConfigSet(&c, "external_pdf_to_md_converter_timeout_sec", value)
			if err == nil {
				t.Fatal("expected validation error")
			}
		})
	}
}

func TestApplyConfigSetMCPTools(t *testing.T) {
	cases := []struct {
		name  string
		value string
		want  []string
	}{
		{"JSON array canonicalizes order", `["crawl","search"]`, []string{"search", "crawl"}},
		{"comma-separated list", "search, scrape", []string{"search", "scrape"}},
		{"mixed case trimmed", " Search , SCRAPE ", []string{"search", "scrape"}},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			cfg := config.Defaults()
			if err := applyConfigSet(&cfg, "mcp_tools", tc.value); err != nil {
				t.Fatal(err)
			}
			if strings.Join(cfg.MCPTools, ",") != strings.Join(tc.want, ",") {
				t.Errorf("MCPTools = %v, want %v", cfg.MCPTools, tc.want)
			}
		})
	}
}

func TestApplyConfigSetMCPToolsClear(t *testing.T) {
	for _, value := range []string{``, `[]`} {
		cfg := config.Defaults()
		cfg.MCPTools = []string{"search"} // set first, then clear
		if err := applyConfigSet(&cfg, "mcp_tools", value); err != nil {
			t.Fatal(err)
		}
		if cfg.MCPTools != nil {
			t.Errorf("value %q: MCPTools = %v, want nil (all tools published)", value, cfg.MCPTools)
		}
	}
}

func TestApplyConfigSetMCPToolsInvalid(t *testing.T) {
	cases := []struct {
		name  string
		value string
		want  string
	}{
		{"unknown tool", `["search","wiki"]`, "unknown tool"},
		{"duplicate", "search,search", "duplicate tool"},
		{"bad JSON", `[not-json]`, "must be a JSON array of strings or a comma-separated list"},
		{"null like spa_markers", `null`, "unknown tool"}, // unmarshals to nil -> "no restriction"
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			cfg := config.Defaults()
			cfg.MCPTools = []string{"search"}
			if err := applyConfigSet(&cfg, "mcp_tools", tc.value); err == nil {
				t.Fatalf("value %q: expected validation error", tc.value)
			} else if !strings.Contains(err.Error(), tc.want) {
				t.Errorf("error %q does not contain %q", err, tc.want)
			}
			if strings.Join(cfg.MCPTools, ",") != "search" {
				t.Errorf("invalid value modified config: %v", cfg.MCPTools)
			}
		})
	}
}

func TestApplyConfigSetSearchOrder(t *testing.T) {
	cases := []struct {
		name  string
		value string
		want  []string
	}{
		{"JSON array keeps the operator's order", `["parallel","keenable","ddg"]`, []string{"parallel", "keenable", "ddg"}},
		{"comma-separated list", "firecrawl, ddg", []string{"firecrawl", "ddg"}},
		{"mixed case trimmed", " Parallel , DDG ", []string{"parallel", "ddg"}},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			cfg := config.Defaults()
			if err := applyConfigSet(&cfg, "search_order", tc.value); err != nil {
				t.Fatal(err)
			}
			if strings.Join(cfg.SearchOrder, ",") != strings.Join(tc.want, ",") {
				t.Errorf("SearchOrder = %v, want %v", cfg.SearchOrder, tc.want)
			}
			if info := buildConfigInfo(cfg, "/fixture/config.json"); strings.Join(info.SearchOrder, ",") != strings.Join(tc.want, ",") {
				t.Errorf("ketch config search_order = %v, want %v", info.SearchOrder, tc.want)
			}
		})
	}
}

func TestApplyConfigSetSearchOrderClear(t *testing.T) {
	for _, value := range []string{``, `[]`} {
		cfg := config.Defaults()
		cfg.SearchOrder = []string{"parallel"}
		if err := applyConfigSet(&cfg, "search_order", value); err != nil {
			t.Fatal(err)
		}
		if cfg.SearchOrder != nil {
			t.Errorf("value %q: SearchOrder = %v, want nil (default chain)", value, cfg.SearchOrder)
		}
	}
}

func TestApplyConfigSetSearchOrderInvalid(t *testing.T) {
	cases := []struct {
		name  string
		value string
		want  string
	}{
		{"auto is the chain, not a member", `["parallel","auto"]`, "not a backend"},
		{"unknown backend", "parallel,google", `unknown backend "google"`},
		{"duplicate", "parallel, PARALLEL", `duplicate backend "parallel"`},
		{"blank entry", "parallel,,ddg", "blank"},
		{"bad JSON", `[not-json]`, "must be a JSON array of strings or a comma-separated list"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			cfg := config.Defaults()
			cfg.SearchOrder = []string{"ddg"}
			err := applyConfigSet(&cfg, "search_order", tc.value)
			if err == nil {
				t.Fatalf("value %q: expected validation error", tc.value)
			}
			if !strings.Contains(err.Error(), tc.want) {
				t.Errorf("error %q does not contain %q", err, tc.want)
			}
			if got := asExitError(t, err); got.Code != ExitValidation {
				t.Errorf("exit code = %d, want %d", got.Code, ExitValidation)
			}
			if strings.Join(cfg.SearchOrder, ",") != "ddg" {
				t.Errorf("invalid value modified config: %v", cfg.SearchOrder)
			}
		})
	}
}

func TestEffectiveMCPTools(t *testing.T) {
	c := config.Defaults()
	// Compared against the registry, not a literal, so publishing a tool does
	// not require editing this expectation.
	if got := effectiveMCPTools(c); strings.Join(got, ",") != strings.Join(config.MCPToolNames(), ",") {
		t.Errorf("unset: effective = %v, want every published tool", got)
	}
	c.MCPTools = []string{"search"}
	if got := effectiveMCPTools(c); strings.Join(got, ",") != "search" {
		t.Errorf("configured: effective = %v, want [search]", got)
	}
	c = config.Defaults()
	c.MCPTools = []string{"wiki"} // hand-edited garbage: reported as-is
	if got := effectiveMCPTools(c); strings.Join(got, ",") != "wiki" {
		t.Errorf("invalid: effective = %v, want raw [wiki]", got)
	}
}

// Backend names are checked against the registries at `config set` time so a
// typo fails loudly instead of persisting a config every command then rejects.
func TestApplyConfigSetBackendValidatesAgainstRegistry(t *testing.T) {
	for _, tc := range []struct{ key, value, wantErr, want string }{
		{"backend", "ddg", "", ""},
		{"backend", " parallel ", "", ""},
		{"backend", "brve", `unknown search backend "brve"`, ""},
		{"backend", "Firecrawl", `unknown search backend "Firecrawl"`, ""},
		{"backend", "", "backend cannot be empty", ""},
		{"code_backend", "sourcegraph", "", ""},
		{"code_backend", "grep", `unknown code backend "grep"`, ""},
	} {
		c := config.Defaults()
		err := applyConfigSet(&c, tc.key, tc.value)
		if tc.wantErr == "" {
			if err != nil {
				t.Errorf("%s=%q: unexpected error %v", tc.key, tc.value, err)
				continue
			}
			got := map[string]string{"backend": c.Backend, "code_backend": c.CodeBackend}[tc.key]
			want := tc.want
			if want == "" {
				want = strings.TrimSpace(tc.value)
			}
			if got != want {
				t.Errorf("%s=%q: stored %q, want %q", tc.key, tc.value, got, want)
			}
			continue
		}
		if err == nil || !strings.Contains(err.Error(), tc.wantErr) {
			t.Errorf("%s=%q: got %v, want error containing %q", tc.key, tc.value, err, tc.wantErr)
			continue
		}
		var ee *ExitError
		if !errors.As(err, &ee) || ee.Code != ExitValidation {
			t.Errorf("%s=%q: want validation exit code, got %v", tc.key, tc.value, err)
		}
		if !strings.Contains(err.Error(), "(valid: ") {
			t.Errorf("%s=%q: error should list valid names: %v", tc.key, tc.value, err)
		}
	}
}

func TestApplyConfigSetExtractMode(t *testing.T) {
	t.Run("sets and normalizes", func(t *testing.T) {
		c := config.Defaults()
		if err := applyConfigSet(&c, "extract_mode", " Clean "); err != nil {
			t.Fatalf("unexpected err: %v", err)
		}
		if c.ExtractMode != "clean" {
			t.Fatalf("ExtractMode = %q", c.ExtractMode)
		}
	})

	t.Run("rejects unknown modes", func(t *testing.T) {
		c := config.Defaults()
		err := applyConfigSet(&c, "extract_mode", "fast")
		var exitErr *ExitError
		if !errors.As(err, &exitErr) || exitErr.Code != ExitValidation || !strings.Contains(err.Error(), "valid: clean, complete") {
			t.Fatalf("error = %v, want exit %d naming the valid modes", err, ExitValidation)
		}
		if c.ExtractMode != "" {
			t.Fatalf("bad value changed config to %q", c.ExtractMode)
		}
	})

	t.Run("empty clears", func(t *testing.T) {
		c := config.Defaults()
		c.ExtractMode = "clean"
		if err := applyConfigSet(&c, "extract_mode", ""); err != nil {
			t.Fatalf("unexpected err: %v", err)
		}
		if c.ExtractMode != "" {
			t.Fatalf("ExtractMode = %q, want empty", c.ExtractMode)
		}
	})

	t.Run("listed among valid keys", func(t *testing.T) {
		c := config.Defaults()
		err := applyConfigSet(&c, "no_such_key", "x")
		if err == nil || !strings.Contains(err.Error(), "extract_mode") {
			t.Fatalf("unknown-key error should list extract_mode: %v", err)
		}
	})
}

func TestBuildConfigInfoShowsEffectiveExtractMode(t *testing.T) {
	info := buildConfigInfo(config.Defaults(), "/tmp/config.json")
	if info.ExtractMode != "clean" {
		t.Fatalf("ExtractMode = %q, want clean", info.ExtractMode)
	}
	c := config.Defaults()
	c.ExtractMode = "complete"
	if info := buildConfigInfo(c, "/tmp/config.json"); info.ExtractMode != "complete" {
		t.Fatalf("ExtractMode = %q, want complete", info.ExtractMode)
	}
}
