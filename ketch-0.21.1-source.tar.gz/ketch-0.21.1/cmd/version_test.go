package cmd

import (
	"encoding/json"
	"strings"
	"testing"

	"github.com/spf13/cobra"
)

func TestVersionDoesNotContactTheNetworkOrReportUpdates(t *testing.T) {
	oldVersion := version
	t.Cleanup(func() { version = oldVersion })
	version = "0.16.1"

	for _, asJSON := range []bool{false, true} {
		t.Run(map[bool]string{false: "text", true: "json"}[asJSON], func(t *testing.T) {
			root := &cobra.Command{Use: "ketch"}
			root.PersistentFlags().Bool("json", asJSON, "")
			root.AddCommand(&cobra.Command{Use: "version", RunE: versionCmd.RunE})
			root.SetArgs([]string{"version"})
			var runErr error
			output := captureStdout(t, func() { runErr = root.Execute() })
			if runErr != nil {
				t.Fatal(runErr)
			}
			if asJSON {
				var payload map[string]any
				if err := json.Unmarshal([]byte(output), &payload); err != nil {
					t.Fatal(err)
				}
				if payload["version"] != version {
					t.Fatalf("unexpected version output: %s", output)
				}
				if _, exists := payload["update"]; exists {
					t.Fatalf("version JSON still contains update-check data: %s", output)
				}
				return
			}
			if !strings.HasPrefix(output, "ketch 0.16.1\n") || strings.Contains(strings.ToLower(output), "update") {
				t.Fatalf("unexpected version output: %s", output)
			}
		})
	}
}
