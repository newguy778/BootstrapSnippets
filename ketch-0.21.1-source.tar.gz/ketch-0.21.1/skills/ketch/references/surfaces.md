# Surfaces — flags, params, and per-surface behavior

Verified against ketch v1.1.0 (main). Discipline 6 applies: `--help` and `ketch config` outrank this file.

---

## CLI ↔ MCP name mapping

The two transports expose the same options under different spellings. Both directions:

In pi, the package's tools are the MCP tools under a `ketch_` prefix — `ketch_search`, `ketch_code`, `ketch_docs`, `ketch_scrape`, `ketch_crawl`, `ketch_tag` — with the MCP option names below; they shell out to the CLI, so `max_pages` is applied client-side there.

| CLI | MCP | Notes |
| --- | --- | --- |
| `--regex` | `regexp` | code; grepapp/sourcegraph only |
| `--select <css>` | `selector` | scrape; skips content selection; incompatible with `raw` |
| positional URLs / JSON array / file / stdin | `url` (one) or `urls` (array) | CLI auto-detects the input form; MCP is explicit |
| `--multi[=list]` | `multi` (array; `["all"]` = every usable) | search; federated RRF search, mutually exclusive with `backend`; CLI needs the `=` form for a list |
| `--resolve` | `resolve` | docs |
| `--section <url#anchor>` | `section` | docs; reads one section, no query: from the local index, or for a page a search read, through the page cache |
| `--page N` | `page` | docs, with `section`: the page of a section longer than `tokens` (pi: none) |
| `--offline` | `offline` | docs; local index only, no network requests; a local miss exits 3 (pi: none) |
| `--random[=list]` | `random` (array) | search; shuffled provider with sequential fallback; mutually exclusive with `backend` and `multi` |
| `--no-llms-txt` | `no_llms_txt` | scrape |
| `--user-agent <ua>` | — | scrape, crawl, search `--scrape`; the User-Agent for every request the run makes (config `user_agent` otherwise) |
| `--cookie-file <path>` | — | scrape, crawl, search `--scrape`; Netscape jar sent to matching hosts |
| `--force-browser` | `force_browser` | scrape |
| `--max-chars` | `max_chars` | scrape / search-with-scrape; crawl has it on MCP only |
| `--no-cache` | `no_cache` | scrape, crawl |
| `--tag <name>` | `tag` | every surface: search, code, docs, scrape, crawl; composes with `--no-cache` |
| `ketch tag add/show/list/remove` | `tag` tool, `operation` enum | the CLI uses verbs, MCP takes `operation: add\|show\|list\|remove` |
| `--concurrency` (scrape, default 5) | `concurrency` (capped at 16) | crawl's `--concurrency` (default 8) is CLI-only |
| — | `max_pages` | crawl, MCP only: default 30, cap 100; CLI crawl bounds with `--depth`/`--allow`/`--deny` |
| `--minimal`, `--json`, `--background` | — | CLI-only; MCP output is already structured |

---

## search

- Backends: `auto` is the default fallback chain, in the order `parallel` → `keenable` → `firecrawl` → `ddg`. The reported `backend` names the provider that answered, and failures on the way appear as CLI warnings or in the MCP `errors` map. The explicit providers are `ddg`, `firecrawl`, `keenable`, and `parallel`. All work without a key. Firecrawl can use a self-hosted `firecrawl_url`; optional Firecrawl, Keenable, and Parallel keys raise hosted limits.
- The effective default backend is operator-configured: **omit `backend` to use it**; `ketch config` shows which it is.
- `--scrape` / `scrape: true` fetches each result's full content — budget it exactly like a scrape (`max_chars`, `trim`).
- `--minimal` (CLI): one result per line, tab-separated url/title/snippet (a 4th backends column is appended under `--multi` for plain search; `--scrape --minimal` keeps 3 columns).
- `--multi` / `multi: [...]`: federated search queries several backends at once and rank-fuses them with Reciprocal Rank Fusion. Bare `--multi` / `["all"]` uses every provider; `--multi=ddg,parallel` / `["ddg","parallel"]` names a set. Each result gains a `backends` list. Backends that error or time out are dropped and reported. The call fails only when every backend fails. It is mutually exclusive with `backend`.

## code

- Backends: `grepapp` (default; keyless, public OSS repos via grep.app), `sourcegraph` (keyless), `github` (auth via `gh auth login`, `$GITHUB_TOKEN`, or `ketch config set github_token <tok>`).
- `lang` is appended to the query as a language filter.
- `repo` / `--repo owner/name` (a GitHub URL also works) searches one repository, exact on every backend. Prefer it to writing `repo:` into the query: grepapp matches the query as literal code, so a typed `repo:`/`lang:` is searched as text and returns a `[validation]` warning (CLI: `warn:` on stderr, `warning.code: literal_qualifier` under `--json`).
- A repository the backend lacks: sourcegraph and github → `[not_found]` / exit 3 naming the other backends. grepapp indexes a subset of public repos, so an empty `repo` search there comes back with a `[not_found]` warning (`repo_may_be_unindexed`), not an error. Try another backend before concluding the code does not exist.
- `regexp` / `--regex`: grepapp and sourcegraph only. github rejects it — `[validation]` / exit 2 with a pointer to the backends that support it.
- grepapp intermittently returns 504 (`[upstream]`); an immediate single retry usually succeeds.

## docs

- Backends: `search` (default) — keyless; answers from the docs themselves. A library the operator indexed (`ketch docs index`) that the question or `library` names answers from the local index. Otherwise it web-searches the question (through the search surface's providers), picks the documentation site the hits agree on (a site the question names, or a spec body's site, first; a site's main docs over enterprise/legacy/pinned-release trees), reads up to 24 of its pages and answers from them, held in memory. A question saves nothing: the pages stay in the page cache for `cache_ttl`, and the same question again within it (same terms, same `library`), answered or refused, does no search and no fetch. Only `ketch docs index` adds libraries or pages. `context7` — curated, version-aware snippets; works with no key on Context7's anonymous quota (about 200 requests a month per IP, shared by everything on that address; a bare search spends two), and a free key lifts it: `ketch config set context7_api_key <key>`. A spent quota is `[upstream]` / exit 4 naming the reset time and that command — do not retry before the reset; drop `backend` to use search. A library Context7 has moved (`/facebook/react` → `/react/react`) is followed once and results carry the new ID. Search is every call's default; Context7 answers only a call that names it (`-b context7`, MCP `backend: "context7"`). The `docs_backend` config key is retired: a stored value is ignored and `config set docs_backend` exits 2 saying so. There is no `web`, `auto` or `local` backend — the local index is part of search.
- Search answers are evidence and a verdict, about 1,800 tokens in all, frontmatter included (or `tokens`); `limit` caps the groups. The fields, in the CLI frontmatter and as `--json` / MCP fields:
  - `index`: `full` or `capped`, pages, `built` date; for pages a search read, `source: search, N pages read` (`index.source`, `pages_read`), `, cached` (`cached: true`) on a repeat from the page cache.
  - `stale`: `unverified, built <date>` when a cited page older than `cache_ttl` could not be read again the way it was stored (no network, a timeout, a check that failed in the last 15 minutes, or `offline`). Absent otherwise.
  - `library`: the root the answer was made from; `scope`: the URL below it the answer was limited to, when `library` named one (see `library` below).
  - `origin`, on an answer from pages a search read (never on one from the index), three values. `verified, <evidence>` only on evidence beyond a name: registry evidence the search agrees with (the root resolve found and the site the search results agree on, chosen without resolve's preference, are one project: `…, and the search results agree`; or a package index's docs of the very package resolve found); the project's own site by registry or repository metadata (a domain its homepage, docs URL or Go module path names); a standard-library page of the language's own docs (`pkg.go.dev documents net/http in the Go standard library`, `docs.python.org documents pathlib in the Python standard library`); the search settling an ambiguity on one candidate's own site; a `library` URL the caller passed. `by name, …` when only a name ties the site to what was asked: a registry package of the name (`<host> documents the <ecosystem> package <name>`, with `; the search results favour <root>` when the search agreed on another site), a domain that carries the name (`the domain <host> carries the name <name>; nothing else confirms it as the official documentation`, for a library value or a question word, docs address or not), a domain named by the repository owner. Else `unverified, ketch could not confirm <host> as the official documentation of <what was asked>` (`for this question` when the question names nothing ketch can confirm as a name), which says only that: the site may still be official. When the resolved root holds none of the question's terms and the search favours another site, that site answers in the same call, its origin ending `; <root>, which resolve found for <name>, holds none of the question's terms, so this answer is from the site the search results favour`. A by-name or unverified answer ends with one clause: unverified `origin unverified: ketch could not confirm this site as the official documentation; name the site you cite, or pass the official docs with --library <docs URL>`; by name `origin by name: only a name ties this site to what you asked; name the site you cite, or pass the docs you mean with --library <resolved root> or --library <favoured root>` (or `--library <docs URL>` with no roots to offer; MCP `hint`: `library="…"`; `--json` `hint` the CLI's words).
  - `status`: `found` (evidence matching the question; not a promise that it answers; pages a search read too, which `source:` says, and `note` names the `ketch docs index` command for those docs when one root holds them); `partial` with `reason` `terms_not_found` and/or `terms_outside_scope`; `refused`, no results, CLI exit 3, over MCP a result, not a tool error: `terms_not_found` (`not_found` is the answer), `terms_outside_scope` (the library holds the terms, but not under `scope`), `scope_empty` (no indexed page is under `scope`; `note` names the root).
  - `terms`: the question's rare terms as written, with the library's sections holding each (the whole library's, with `scope` too); `not_found`: those no section of the library holds; `outside_scope`: those the library holds but no section under `scope` does.
  - `defined_in`: for a listed term that is the first cell of a table row in a section the answer does not print, and that section names another of the question's rare terms (when it has one), that section (CLI `defined_in: {term: url#anchor}`; JSON/MCP `[{term, section}]`; at most three).
  - `indexed_near`: when `library` named no indexed library, the indexed ones near it (one to five: those on the URL's host, else those its path names, so `github.com/owner/repo` lists the project's docs and not the code host's, else those whose name, title or root holds the value or one of its words), answered from none of them (CLI `indexed_near: {title: root}`, ending with a line saying to pass one as `--library`; JSON/MCP `[{title, library}]`, MCP `hint` says the same). A refusal or failure of such a call names them at the end of its error.
  - Results, one per section group, best first, a page's together: `page_title`, `heading_path`, `url`, `section` (the reference for `--section`), `rows`, `same_text`; a cut group has `truncated`, `shown_tokens` of `section_tokens` (CLI `(cut, N of M tokens)` on its `source:` line) and `contents` (CLI `also in this section: …`). A result names no backend: the answer's `backend` does, once. `…` in a group's text marks text left out. A cut group prints a code block with the sentence that introduces it (one ending in a colon), a sentence opening with `Or`, `Otherwise`, `This` or `The above` with the one before it, and a signature or a term with its type with the description under it.
  - `hint`, when a group was cut: how many are, that their hidden text is unread, and the call that reads it, to run before stating what it says. CLI text: last line `N groups above are cut and their hidden text is unread: run ketch docs --section <its source> before stating what it says`; `--json` `hint`: `N results are truncated and …: run ketch docs --section <its section> …`; MCP `hint`: `… read docs(section="<its section>") …`. With `indexed_near` the MCP and `--json` hint add its line after `; `.
  - Two rules of use: text behind `…` or in a cut group is unread (read it with `section` before stating what it says, or say you did not read it); whatever an answer says that no result prints is the caller's own knowledge, labelled so, never cited to the docs.
  - A code block is printed as stored: HTML in it is the example's own (a parser's output, a template), never stripped.
- **Read a cut result with `section`, don't re-ask with more tokens.** Pass a result's `section` (or a `defined_in` target) with no query: it returns the section and its subsections (an H2 is its whole family; a page URL alone, the page's sections in order) from the local index, or for a page a search read, through the page cache (read again from the site after `cache_ttl`). Whole when it fits `tokens` (default 4000), else a page of that size at a time, broken at a block boundary: `page: N of M`, then `next page: …` (`page=N`; a page past the last is `[validation]`). Its frontmatter is an answer's lines about the source (`backend`, `library`, `index:` or `source:`, `stale:`, `page:`), no verdict; `--json` and MCP give the same object as an answer, `results` holding the section. Its text is cleaned as an answer's is (`pam\_duo` prints `pam_duo`). An unknown page or anchor is `[not_found]`; a malformed reference or `backend: context7` with `section` is `[validation]`.
- `library` / `--library`: Context7 takes its `/org/repo` ID. Search takes one spec; a name no indexed library matches is resolved while the question is searched (up to 6 s, beside the search), and the docs root resolve verifies is read, unless the site the search agrees on is that project's own; a name several verified libraries share is `[validation]` / exit 2 listing each with its packages and title, unless the search agrees on exactly one's own site; a Go standard-library path (`net/http`, `context`) is its pkg.go.dev page, ahead of a Go module named like it, and a Python standard-library module (`pathlib`) its docs.python.org page, ahead of a same-named PyPI package; beside a library of another ecosystem the page is one candidate, picked by a language word or the search's agreement, else refused with the others. On a host that serves many projects (a package index's docs, a module path's host) only the named project's path is read. A docs URL: that site is read, a page URL that page first:
  - a docs root as `resolve` lists it. A URL below an indexed root narrows the answer to the pages at or under it (a page URL: that page), printed as `scope:` with the root as `library`; no indexed page under it is `refused (scope_empty)`, never widened. To read one page whole, use `section`. A docs URL no index holds is read as given (`https://docs.astro.build`); it already names its version, so `<url>@x` is `[validation]`; one below the site's docs tree is searched within and printed as `scope:`. A URL without its scheme (`auth0.com/docs`) that no name or package matches is compared with the indexed roots as the URL it names;
  - an indexed library's name: its site's name (`Vue Router`), that name without words such as Project, Community, Web Framework or Developer (`django` for Django Project), its package names, or its host's one distinctive label (`duo` for duo.com). A library of one page (a specification indexed at its own address) also goes by its document's title, the acronym the document spells out for that title (`jwt`, `pkce`) and a name in it with its version (`oauth 2.0`, `oauth2`). One word of a longer name is not a name (`vue` is not Vue Router; `oauth` names neither of two OAuth RFCs), nor is a vendor's name for a product it documents under its own path (`hashicorp` is not Terraform);
  - `[eco:]name[@version]` — `click`, `django@5.2`, `next@14`, `pypi:click`, `npm:@astrojs/starlight@0.30`; prefixes `npm:` `pypi:` `crates:`/`cargo:` `go:` `github:`; a bare name is looked up in npm, PyPI and crates.io;
  - `owner/repo` (a GitHub repository), or a Go module path (`github.com/spf13/cobra`).
  - `@version`: exact label, alias (`latest`/`stable`, `dev`/`main`), or a prefix that picks the newest release under it (`5` → newest `5.x`), never across a major.
- Without `library`: search picks the site from the question's hits (and an indexed library the question names); a name the question opens with that resolve verifies strictly (an exact package name, its own docs site, trust 5) is read like a `library`. Context7 resolves the whole query.
- `resolve`: Search answers from the local index first, with no network: the indexed libraries whose root, title (for a library of one page, its document's), site name, names, aliases or package specs hold the query (case aside; failing that, one of its words of three letters or more), every one with no query (`ketch docs --resolve`, MCP `resolve=true` alone): `<root>  <title>  (indexed: yes, full|capped, N pages, built <date>)`, `--json`/MCP `indexed: true` and `index`. Only a name none matches goes to the web resolution below, and only a name without spaces: a name of several words none matches (compared also as one key: `vercel ai sdk` holds AI SDK) is `[not_found]`, since registries take package names; its message says that `resolve` with no name lists every indexed library. Context7 — `/org/repo  Name  (snippets: N, trust: X)`. **Context7's resolve never returns empty.** A garbage query returns confident fuzzy matches, some with trust 8–10. Trust scores the source, not the match — vet that the *name* is the library you meant before fetching by ID. Search — `<docs root URL>  Name  (trust: X, version: V, versions: a b c)`, then indented `packages:` and `evidence:`; `--json` and MCP `matches` add `version`, `versions`, `evidence` and `packages`. Only verified matches (the registry entry or repository names the site, the package's docs.rs/pkg.go.dev docs, or a site on the project's domain linking back to its repository); several projects answering to a name are all listed. A GitHub rate limit shows up as an evidence note, not a failure.
- Search errors: `[not_found]` / exit 3 — no documentation among the hits (`no_docs_found`), none of the pages readable (the error counts them per cause, `not found`, `blocked (HTTP 403)`, `need JavaScript`, `empty after extraction`, `timed out`, `redirected outside the root`, and names the next step: configure `browser`, the site's parent as `library`, `ketch docs index`), no page to read under the root, `robots.txt` disallows them (`disallowed`), nothing matched (`no_results`). When the site read first gave no text and the next answered, the answer's `note` says `could not read <root> (…)`. `[validation]` / exit 2 — with a `library` name resolve knows, the search agrees on no site (`ambiguous`): every library resolve knows by the name is listed with its title and packages (`the search results agree on no site for "<name>"; resolve knows it as: …`); with no name resolve knows, or none given, the hits split between sites (`ambiguous_site`, `the search results are split between several sites, none ahead and none tied to what was asked: …`): pass the docs you mean as `library` (a docs URL). `[upstream]` / exit 4 — every web search failed or came back empty (`search_empty`: the search providers are throttling), or no answer within 45 s. A refusal for want of the question's terms (`terms_not_found`, `terms_outside_scope`, `scope_empty`) is not among these: it is the result described under `status` above, exit 3 on the CLI with its frontmatter printed. An empty answer is never a success: Context7's is `[not_found]` (`no_results`), and on search `no_results` is rare.
- `tokens`: leave it unset unless a result is too long to read. Search answers in about 1,800 tokens unless set, frontmatter included; Context7's default is 4000 (~3.3 KB).

## scrape

- **llms.txt:** a bare-domain URL is auto-probed for `/llms.txt` first and may silently return that file instead of the homepage. The `title` in the output reveals the swap. `no_llms_txt` / `--no-llms-txt` opts out.
- Input forms (CLI, auto-detected — no batch flag): single URL, multiple positional args, a JSON array string, a file of URLs, a stdin pipe. MCP: exactly one of `url` or `urls`.
- Batch scrapes run concurrently (CLI default 5; MCP `concurrency` capped at 16). Over MCP, per-URL failures come back as `results[].error` **inside a successful call** (`isError=false`, one entry per URL in input order). On the CLI the same failure is a `warn:` stderr line and the URL is omitted from the output array, so match the results against the URLs you asked for.
- `max_chars` truncates output and appends `[truncated]`. `trim` strips markdown syntax, keeps text (incompatible with `raw`). `--select`/`selector` extracts by CSS selector, skipping content selection — no match is `[not_found]` / exit 3. `raw` returns HTML instead of markdown.
- JS-rendered pages: JS-shell detection falls back to the configured headless browser automatically, same output shape. `force_browser` skips detection and errors without a configured browser (`[precondition]`).
- Fetches are cached (see Cache below); `no_cache` bypasses.
- Already hold the HTML? `curl -L <url> | ketch extract` runs the same structural extraction + markdown pipeline with no fetch, cache, or browser (CLI-only; supports `--url`, `--select`, `--trim`, `--max-chars`).

## crawl

- Same-host BFS from a seed URL (`--sitemap` treats the seed as a sitemap). Streams pages as found.
- **MCP:** synchronous and bounded — `max_pages` default 30, hard cap 100, 3-minute wall clock. Partial results return with `stopped: "max_pages" | "timeout"`. Per-page `max_chars` available.
- **CLI:** `--depth` (default 3), `--allow` path substrings, `--deny` regexes, `--concurrency` (default 8). No page-cap flag — bound with depth and filters.
- **Background mode is CLI-only:** `ketch crawl <url> --background` returns a crawl ID; `ketch crawl status [id]` and `ketch crawl stop <id>` manage it.
- A CLI crawl interrupted by SIGINT exits **0** with the partial results already streamed — by design, not an error.

---

## tag

Not a research surface: it answers "what did I already find?", not "what is out
there?". No network on any `tag` operation.

`--tag` / the `tag` option works on **every** surface, and one tag holds them
all. Each entry keeps a source URL, bounded title and description, and tagging
time. Descriptions derive from fetched content, code/docs snippets or search
results; full bodies stay in the separate page cache.

| Operation | CLI | MCP |
| --- | --- | --- |
| Tag what a call returned | `--tag <name>` on `search` / `code` / `docs` / `scrape` / `crawl` | `tag` option on those tools |
| Tag URLs directly (cached or not) | `ketch tag add <name> <url>...` | `operation: add`, `urls` |
| Read the index | `ketch tag show <name> --limit N` (`--minimal` for tab-separated) | `operation: show`, `limit` |
| List tags | `ketch tag list` | `operation: list` |
| Drop a tag, or pages from it | `ketch tag remove <name> [url...]` | `operation: remove`, optional `urls` |

`show` returns titles, URLs, one-line descriptions and a `cached` flag per page,
newest first. Both surfaces default to 50 entries; 0 selects all and negatives
are validation errors. `entries`/`cached` count the whole tag, `shown` counts
returned pages. A source can carry several tags. Membership uses the displayed
URL regardless of cookie, User-Agent or rewrite settings.

**The index outlives the cached bodies.** `cache_ttl` defaults to 72h; index
entries have no TTL. An entry with `cached: false` has no confirmed fresh body;
it does not imply a dead link. If `cache_status: unavailable`, warmth could not
be checked because the page cache was locked or unreadable. `scrape` the URL
when you need its content. `ketch cache clear`
drops bodies and keeps the index. Nothing expires the index, so `remove` is the
only way a tag ends.

`add` accepts a URL whose page was never fetched: it is indexed with no title
or description, listed as uncached, and both fill in the first time the page is
seen by any route. The returned `not_cached` array names those — scrape them if
you want the index to describe them now. `add` requires absolute `http(s)` URLs
with a host — anything else is `[validation]` / exit 2, and a batch with one bad
URL tags nothing. `remove` with URLs returns `missing` for the ones that were not
under the tag; a batch that removes nothing is `[not_found]` / exit 3.

`cached: false` is the normal state for entries from `code`, `docs` and
unscraped `search`: those surfaces return snippets, not fetched pages. The
snippet is kept as the entry's description, so the index is still useful
without a round trip.

Errors: `remove` that matches nothing is `[not_found]` / exit 3, including JSON
mode. Explicit tag storage failures are `[precondition]` / exit 5. Optional
bookmark write failures retain research output with CLI stderr diagnostics
(`warning.code: tag_write_failed` under `--json`) or MCP `warnings`.

Storage is `tags.db` under the native configuration directory (Linux XDG config,
macOS Application Support, Windows AppData), with `KETCH_TAGS_PATH` as a complete
filename override. Both tags.db and the page cache open per operation, so a
running MCP server or crawl never locks the CLI out. Cache clear deletes the
page-cache file and leaves bookmarks alone.

---

## Backends and keys at a glance

| Surface | Keyless | Keyed | Set with |
| --- | --- | --- | --- |
| search | **auto (default)**, ddg, firecrawl, keenable, parallel | optional keys only | `ketch config set firecrawl_api_key <key>` / `keenable_api_key` / `parallel_api_key`; `firecrawl_url` selects a self-hosted instance |
| code | grepapp, sourcegraph | github | `gh auth login` / `$GITHUB_TOKEN` / `ketch config set github_token <tok>` |
| docs | **search (default;** finds docs sites through the search surface, so search keys help it; `gh auth login` / `github_token` lifts GitHub's 60 req/h limit on name resolution**)**, context7 (anonymous quota, ~200 req/month per IP) | context7 (free key lifts the quota) | `ketch config set context7_api_key <key>`; Context7 answers a call that names it (`-b context7`); `docs_backend` is retired |

Search needs no key on any retained backend. Optional keys raise hosted limits.

---

## Config

- File: `~/.config/ketch/config.json`. Flags always override config values.
- `ketch config` is the one discovery call: effective settings plus `available_backends`, `available_code_backends`, `available_doc_backends`, as JSON. Never probe env vars instead.
- `ketch config` reports whether each retained API key is set. Use `ketch doctor` to test reachability.
- Keys include `backend`, `code_backend`, `docs_backend` (retired and ignored), `limit`, `sourcegraph_url`, `context7_api_key`, `github_token`, `firecrawl_api_key`, `firecrawl_url`, `keenable_api_key`, `parallel_api_key`, `browser`, `cache_ttl`, `url_rewrites`, `spa_markers`, `cookie_file`, `user_agent` (the UA every request sends, page fetches and APIs alike; unset is a desktop-Chrome-on-macOS string), `extract_mode`, and `mcp_tools`.
- `KETCH_CONFIG` selects the config filename. Isolate bookmark labs with `KETCH_TAGS_PATH` too; on Linux, `XDG_CACHE_HOME` isolates page bodies. macOS and Windows use their native cache directories, so an XDG override alone is not portable isolation.
- `user_agent` is the identity every request sends: page fetches, the headless browser, and the search/code/docs APIs. Unset, ketch presents as a desktop Chrome on macOS (User-Agent plus `Accept-Language`, `Accept`, `Sec-Fetch-*`, and over https `Sec-CH-UA`); a configured value is sent as that User-Agent alone, with no Chrome hints. `--user-agent` overrides it for one run, on any surface.

## Cache

- Page cache in bbolt at `~/.cache/ketch/cache.db`, default TTL 72h (`cache_ttl` overrides). `ketch cache` shows page-cache stats and the tag index (path, counts, lock state), `ketch cache clear` empties the page cache and keeps bookmarks; both take `--json`.
- Single-process lock: the bbolt DB admits one process at a time. A long-running MCP server holds the lock for its whole lifetime, so concurrent CLI scrapes silently run cache-disabled — every fetch goes to the network. Observed live: `ketch doctor` reports `cache … locked by another process` while the server runs, and `ketch cache` shows `locked: true`. Needing heavy CLI and MCP use long-term → prefer CLI-only, or accept the tradeoff knowingly.
