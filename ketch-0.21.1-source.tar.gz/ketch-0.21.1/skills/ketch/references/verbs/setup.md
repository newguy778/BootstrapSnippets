# ketch setup

Setup is a configuration assistant, not a configuration script. It reads the current state, probes what actually works, proposes exact commands, and mutates **only after the operator confirms**. It never touches a value that is already configured and working.

---

## The state problem — be honest about it

Prefer `ketch doctor --json` when available. It probes every configured surface in one call and exits 0 when everything configured is healthy, or 5 when a configured item is broken. `ketch config` also reports key presence as booleans such as `firecrawl_api_key_set`.

On older ketch versions without `doctor`, configured-state detection is imperfect: `ketch config` shows effective settings and available backends, but does **not** report whether search/docs API keys are set (the one exception: `github_token_source`), and it never reports reachability. Read the config, then send one probe per surface the operator cares about, and classify the result by error class.

---

## Flow

1. **Read** (read-only): `ketch config` and `ketch browser status`. Note the effective backend per surface.
2. **Probe** each surface in play — `ketch doctor --json` when available; on older versions, one cheap read-only call each:

   | Surface | Probe | Healthy | Needs setup | Unreachable |
   | --- | --- | --- | --- | --- |
   | search | `ketch search "test" -l 1` | exit 0 | exit 5 `[precondition]` | exit 4 `[upstream]` |
   | code | `ketch code "test" -l 1` | exit 0 | exit 5 | exit 4 |
   | docs | `ketch docs --resolve "react" -l 1` (search; `-b context7` probes Context7 and spends quota) | exit 0 | exit 5 | exit 4 |
   | scrape | `ketch scrape https://example.com --max-chars 200` | exit 0 | — | exit 4 |
   | browser | `ketch browser status` | `status: ok` | not configured | — |

   Exit 4 means reachability (instance down, network, rate limit), not configuration — investigate before proposing any `config set`.
3. **Propose.** State per surface: current state, what you recommend changing, what you will *not* touch because its probe is healthy, and the exact commands. Then wait. No `config set`, `browser install`, or `docker run` before an explicit yes.
4. **Apply** exactly the confirmed commands, nothing extra.
5. **Verify.** Re-run the probe for each changed surface; report exit code / error prefix.

---

## Search backend decision tree

1. **auto.** This is the zero-setup default. It tries Parallel, Keenable, Firecrawl, then DuckDuckGo, and returns the first answer. Under heavy fan-out all four can rate-limit, which produces `[upstream]` or exit 4.
2. **parallel.** The hosted Search MCP works without a key. `ketch config set parallel_api_key <key>` raises the anonymous limits. Select it with `ketch config set backend parallel`.
3. **keenable.** The public endpoint works without a key. `ketch config set keenable_api_key <key>` raises its rate limit. Select it with `ketch config set backend keenable`.
4. **firecrawl.** The hosted v2 search API works without a key. `ketch config set firecrawl_api_key <key>` raises the hosted limit. For a self-hosted instance, set `firecrawl_url`, for example `ketch config set firecrawl_url http://localhost:3002`. Select it with `ketch config set backend firecrawl`.
5. **ddg.** DuckDuckGo needs no key and has no provider-specific settings. It rate-limits more readily during federated searches.

If the operator wants a fixed fallback order, `search_order` pins `auto` to the listed backends:

```sh
ketch config set search_order ddg,parallel,firecrawl
```

---

## Code, docs, browser

- **code:** `grepapp` is the default and keyless — a healthy probe means leave it alone. `sourcegraph` is keyless too (`sourcegraph_url` can point at another instance). `github` needs auth by any of: `gh auth login`, `$GITHUB_TOKEN`, or `ketch config set github_token <tok>`.
- **docs:** the default backend, `search`, needs nothing: it finds docs sites through the `search` surface (a healthy search means docs can search too), saves nothing from a question (the pages stay in the page cache for `cache_ttl`), and `ketch docs index <library|docs-url>` indexes a docs site for offline answers (`ketch doctor`'s `search` docs row says how many libraries are indexed). Resolving a library name asks GitHub about its repository, and the `code` surface's GitHub auth (`gh auth login`, `$GITHUB_TOKEN` or `github_token`) lifts the 60-requests-an-hour unauthenticated limit. `context7` is the other backend, for a call that names it (`-b context7`, MCP `backend: "context7"`): it works with no key on Context7's anonymous quota — about 200 requests a month per IP, shared by everything on that address; `ketch doctor` shows it as `keyless` with the requests left as of the last Context7 response (or `quota not yet seen`) and spends none of them. A free key lifts it: `ketch config set context7_api_key <key>`. The `docs_backend` config key is retired: a stored value (often `context7`, an older default) is ignored, and `ketch config set docs_backend` exits 2 saying so.
- **browser** (JS-rendered pages): check `ketch browser status`. Either point at an installed binary — `ketch config set browser <binary>` — or download Chromium with `ketch browser install`. Both are mutations: propose, confirm.
- **identity (`user_agent`)**: unset, ketch presents as a desktop Chrome on macOS on every request — page fetches, the headless browser, and the search/code/docs APIs — with matching `Accept-Language`, `Accept`, `Sec-Fetch-*` and (over https) `Sec-CH-UA`. `ketch config set user_agent "<ua>"` replaces it everywhere, and `""` restores the default; `--user-agent` covers one run. A custom value is sent as that User-Agent alone, with no Chrome hints that would contradict it. Propose it only when the operator asks for a different identity or a site's policy requires one: it changes what every backend sees, not one call.

---

## Rules

- Propose-then-confirm on every mutation; the proposal quotes the exact command.
- Never modify a surface whose probe is healthy.
- Exit 4 from a probe is a reachability problem — do not "fix" it with `config set`.
- Report the end state as a table: `surface | backend | probe result`.
- `ketch doctor --json` replaces the hand-rolled probes when available (`ketch doctor --help` exits 0); the propose→confirm→verify loop stays either way.
