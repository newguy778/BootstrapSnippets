package search

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"reflect"
	"strings"
	"testing"
)

func deterministicPool(keys ...string) keyPool {
	pool := newKeyPool(keys)
	pool.randIntN = func(int) int { return 0 }
	return pool
}

func rewrittenClient(target string) *http.Client {
	return &http.Client{Transport: &rewriteTransport{base: http.DefaultTransport, target: target}}
}

func TestFirecrawlRotatesKeyOn402(t *testing.T) {
	var got []string
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		got = append(got, strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer "))
		if len(got) == 1 {
			w.WriteHeader(http.StatusPaymentRequired)
			return
		}
		_, _ = fmt.Fprint(w, `{"success":true,"data":{"web":[]}}`)
	}))
	defer server.Close()

	backend := &Firecrawl{keys: deterministicPool("first", "second"), client: rewrittenClient(server.URL)}
	if _, err := backend.Search(context.Background(), "q", 1); err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(got, []string{"first", "second"}) {
		t.Fatalf("keys used = %v", got)
	}
}

func TestKeenableRotatesKeyOn429(t *testing.T) {
	var got []string
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		got = append(got, r.Header.Get("X-API-Key"))
		if len(got) == 1 {
			w.WriteHeader(http.StatusTooManyRequests)
			return
		}
		_, _ = fmt.Fprint(w, `{"results":[]}`)
	}))
	defer server.Close()

	backend := &Keenable{keys: deterministicPool("first", "second"), client: rewrittenClient(server.URL)}
	if _, err := backend.Search(context.Background(), "q", 1); err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(got, []string{"first", "second"}) {
		t.Fatalf("keys used = %v", got)
	}
}

func TestRetainedBackendsRetryCredentialFailures(t *testing.T) {
	tests := []struct {
		name        string
		status      int
		successBody string
		newBackend  func(*http.Client) Searcher
		requestKey  func(*http.Request) string
	}{
		{
			name:        "firecrawl 401",
			status:      http.StatusUnauthorized,
			successBody: `{"success":true,"data":{"web":[]}}`,
			newBackend: func(client *http.Client) Searcher {
				return &Firecrawl{keys: deterministicPool("first", "second"), client: client}
			},
			requestKey: func(r *http.Request) string { return strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ") },
		},
		{
			name:        "firecrawl 429",
			status:      http.StatusTooManyRequests,
			successBody: `{"success":true,"data":{"web":[]}}`,
			newBackend: func(client *http.Client) Searcher {
				return &Firecrawl{keys: deterministicPool("first", "second"), client: client}
			},
			requestKey: func(r *http.Request) string { return strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ") },
		},
		{
			name:        "keenable 401",
			status:      http.StatusUnauthorized,
			successBody: `{"results":[]}`,
			newBackend: func(client *http.Client) Searcher {
				return &Keenable{keys: deterministicPool("first", "second"), client: client}
			},
			requestKey: func(r *http.Request) string { return r.Header.Get("X-API-Key") },
		},
		{
			name:        "parallel 401",
			status:      http.StatusUnauthorized,
			successBody: `{"jsonrpc":"2.0","id":1,"result":{"content":[{"type":"text","text":"{\"results\":[]}"}]}}`,
			newBackend: func(client *http.Client) Searcher {
				return &Parallel{keys: deterministicPool("first", "second"), client: client, endpoint: parallelEndpoint}
			},
			requestKey: func(r *http.Request) string { return strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ") },
		},
		{
			name:        "parallel 429",
			status:      http.StatusTooManyRequests,
			successBody: `{"jsonrpc":"2.0","id":1,"result":{"content":[{"type":"text","text":"{\"results\":[]}"}]}}`,
			newBackend: func(client *http.Client) Searcher {
				return &Parallel{keys: deterministicPool("first", "second"), client: client, endpoint: parallelEndpoint}
			},
			requestKey: func(r *http.Request) string { return strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ") },
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			var got []string
			server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				got = append(got, tc.requestKey(r))
				if len(got) == 1 {
					w.WriteHeader(tc.status)
					return
				}
				_, _ = fmt.Fprint(w, tc.successBody)
			}))
			defer server.Close()

			backend := tc.newBackend(rewrittenClient(server.URL))
			if _, err := backend.Search(context.Background(), "q", 1); err != nil {
				t.Fatal(err)
			}
			if !reflect.DeepEqual(got, []string{"first", "second"}) {
				t.Fatalf("keys used = %v, want first then second", got)
			}
		})
	}
}
