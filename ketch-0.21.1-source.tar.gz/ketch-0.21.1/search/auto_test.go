package search

import (
	"context"
	"errors"
	"reflect"
	"slices"
	"strings"
	"testing"
	"time"

	config "github.com/1broseidon/ketch/internal/configbase"
)

func newTestAuto(budget time.Duration, backends ...namedSearcher) *Auto {
	return &Auto{backends: backends, timeout: 50 * time.Millisecond, budget: budget}
}

// A zero-config install must resolve a chain of keyless providers and nothing
// else: every retained provider is keyless and available.
func TestAutoChainDefaultsToKeylessProviders(t *testing.T) {
	t.Parallel()
	cfg := config.Defaults()

	want := []string{"parallel", "keenable", "firecrawl", "ddg"}
	if got := AutoChainNames(&cfg); !reflect.DeepEqual(got, want) {
		t.Fatalf("AutoChainNames() = %v, want %v", got, want)
	}
}

// A keyless provider the operator gave a key to is a deliberate choice too, so
// it is promoted on the same rule rather than staying at its keyless rank.
func TestAutoChainPromotesKeyedKeylessProvider(t *testing.T) {
	t.Parallel()
	cfg := config.Defaults()
	cfg.SetProvider("firecrawl_api_key", "configured")

	got := AutoChainNames(&cfg)
	if len(got) == 0 || got[0] != "firecrawl" {
		t.Fatalf("AutoChainNames() = %v, want firecrawl promoted to first", got)
	}
}

// search_order is the whole order: listed providers are tried exactly as
// given, a configured provider is not promoted past it, and nothing unlisted
// joins the chain.
func TestAutoChainHonoursSearchOrderExactly(t *testing.T) {
	t.Parallel()
	cfg := config.Defaults()
	cfg.SetProvider("firecrawl_api_key", "configured") // would be promoted first without search_order
	cfg.SearchOrder = []string{"ddg", "keenable", "firecrawl"}

	if got, want := AutoChainNames(&cfg), []string{"ddg", "keenable", "firecrawl"}; !reflect.DeepEqual(got, want) {
		t.Fatalf("AutoChainNames() = %v, want %v", got, want)
	}
}

// A provider with AutoRank 0 never joins the default chain, but the operator's
// list is not filtered by rank. Not parallel: it registers a provider.
func TestAutoChainSearchOrderAdmitsUnrankedKeyedProvider(t *testing.T) {
	t.Cleanup(RegisterTestProvider(Provider{
		ID: "unranked", Name: "Unranked",
		Usable: func(c *config.Config) bool { return c.String("unranked_api_key") != "" },
		New:    func(*config.Config) (Searcher, error) { return &fakeSearcher{}, nil },
	}))
	cfg := config.Defaults()
	cfg.SetProvider("unranked_api_key", "configured")
	if slices.Contains(AutoChainNames(&cfg), "unranked") {
		t.Fatal("an AutoRank-0 provider joined the default chain")
	}

	cfg.SearchOrder = []string{"unranked", "ddg"}
	if got, want := AutoChainNames(&cfg), []string{"unranked", "ddg"}; !reflect.DeepEqual(got, want) {
		t.Fatalf("AutoChainNames() = %v, want %v", got, want)
	}
}

// A hand-edited config file bypasses `config set`, so the chain itself must
// refuse an invalid list rather than silently fall back to the default order.
func TestNewAutoFromConfigRejectsInvalidSearchOrder(t *testing.T) {
	t.Parallel()
	for _, order := range [][]string{{"auto"}, {"wiki"}, {"ddg", "DDG"}, {" "}} {
		cfg := config.Defaults()
		cfg.SearchOrder = order
		if got := AutoChainNames(&cfg); len(got) != 0 {
			t.Errorf("search_order %q: AutoChainNames() = %v, want empty", order, got)
		}
		_, err := NewFromConfig(&cfg, AutoBackend)
		if err == nil || !strings.Contains(err.Error(), "invalid search_order") {
			t.Errorf("search_order %q: err = %v, want invalid search_order", order, err)
		}
	}
}

// An empty list is the default chain, byte for byte.
func TestAutoChainEmptySearchOrderIsTheDefault(t *testing.T) {
	t.Parallel()
	defaults := config.Defaults()
	want := AutoChainNames(&defaults)
	cfg := config.Defaults()
	cfg.SearchOrder = []string{}
	if got := AutoChainNames(&cfg); !reflect.DeepEqual(got, want) {
		t.Fatalf("AutoChainNames() = %v, want the default %v", got, want)
	}
}

func TestNormalizeSearchOrder(t *testing.T) {
	t.Parallel()
	got, err := NormalizeSearchOrder([]string{" Parallel", "KEENABLE ", "ddg"})
	if err != nil {
		t.Fatal(err)
	}
	if want := []string{"parallel", "keenable", "ddg"}; !reflect.DeepEqual(got, want) {
		t.Fatalf("NormalizeSearchOrder() = %v, want %v (order preserved)", got, want)
	}
	if got, err := NormalizeSearchOrder(nil); got != nil || err != nil {
		t.Fatalf("NormalizeSearchOrder(nil) = %v, %v; want nil, nil", got, err)
	}
	for list, want := range map[string]string{"auto": "not a backend", "wiki": "unknown backend", "ddg,Ddg": "duplicate backend", "": "blank"} {
		if _, err := NormalizeSearchOrder(strings.Split(list, ",")); err == nil || !strings.Contains(err.Error(), want) {
			t.Errorf("NormalizeSearchOrder(%q) err = %v, want %q", list, err, want)
		}
	}
}

func TestAutoSearchReportsServingBackend(t *testing.T) {
	t.Parallel()
	want := []Result{{Title: "served", URL: docURL("served")}}
	auto := newTestAuto(time.Second,
		namedSearcher{name: "first", searcher: &fakeSearcher{results: want}},
		namedSearcher{name: "second", searcher: &fakeSearcher{err: errors.New("must not run")}},
	)

	results, served, failures, err := auto.SearchSelect(context.Background(), "q", 5)
	if err != nil {
		t.Fatal(err)
	}
	if served != "first" {
		t.Fatalf("served = %q, want first", served)
	}
	if !reflect.DeepEqual(results, want) || len(failures) != 0 {
		t.Fatalf("results=%v failures=%v", results, failures)
	}
}

// The whole point of the chain: a rate-limited provider must not fail the
// command when a working one sits behind it.
func TestAutoSearchFallsBackOnError(t *testing.T) {
	t.Parallel()
	want := []Result{{Title: "second", URL: docURL("second")}}
	auto := newTestAuto(time.Second,
		namedSearcher{name: "limited", searcher: &fakeSearcher{err: errors.New("rate limited")}},
		namedSearcher{name: "healthy", searcher: &fakeSearcher{results: want}},
	)

	results, served, failures, err := auto.SearchSelect(context.Background(), "q", 5)
	if err != nil {
		t.Fatal(err)
	}
	if served != "healthy" || !reflect.DeepEqual(results, want) {
		t.Fatalf("served=%q results=%v", served, results)
	}
	if len(failures) != 1 || failures[0].Backend != "limited" {
		t.Fatalf("failures = %+v, want the limited provider reported", failures)
	}
}

// Zero results is an answer, not a failure. Falling through on empty would
// turn every legitimately-unmatched query into a sweep of every provider —
// which is exactly why a provider must never report an error as empty.
func TestAutoSearchStopsOnEmptyResults(t *testing.T) {
	t.Parallel()
	auto := newTestAuto(time.Second,
		namedSearcher{name: "empty", searcher: &fakeSearcher{results: nil}},
		namedSearcher{name: "next", searcher: &fakeSearcher{err: errors.New("must not run")}},
	)

	results, served, failures, err := auto.SearchSelect(context.Background(), "q", 5)
	if err != nil {
		t.Fatal(err)
	}
	if served != "empty" || len(results) != 0 || len(failures) != 0 {
		t.Fatalf("served=%q results=%v failures=%v", served, results, failures)
	}
}

func TestAutoSearchAllBackendsFail(t *testing.T) {
	t.Parallel()
	auto := newTestAuto(time.Second,
		namedSearcher{name: "one", searcher: &fakeSearcher{err: errors.New("down")}},
		namedSearcher{name: "two", searcher: &fakeSearcher{err: errors.New("also down")}},
	)

	_, _, failures, err := auto.SearchSelect(context.Background(), "q", 5)
	if err == nil {
		t.Fatal("expected an error when every backend fails")
	}
	if len(failures) != 2 {
		t.Fatalf("failures = %+v, want both reported", failures)
	}
	// The error has to name what was tried; "search failed" alone leaves an
	// operator with nowhere to start.
	for _, want := range []string{"all 2 backends failed", "one", "two"} {
		if !strings.Contains(err.Error(), want) {
			t.Errorf("error = %q, want it to contain %q", err, want)
		}
	}
}

// Attempts are sequential, so without a chain-wide budget a row of slow
// providers multiplies the per-attempt timeout by the chain's length.
func TestAutoSearchStopsAtTotalBudget(t *testing.T) {
	t.Parallel()
	slow := func(name string) namedSearcher {
		return namedSearcher{name: name, searcher: &fakeSearcher{delay: time.Hour}}
	}
	auto := newTestAuto(120*time.Millisecond, slow("one"), slow("two"), slow("three"), slow("four"), slow("five"))

	start := time.Now()
	_, _, failures, err := auto.SearchSelect(context.Background(), "q", 5)
	elapsed := time.Since(start)

	if err == nil {
		t.Fatal("expected an error when the budget is exhausted")
	}
	if !strings.Contains(err.Error(), "budget") {
		t.Errorf("error = %q, want it to mention the budget", err)
	}
	// Five 50ms attempts would be 250ms; the 120ms budget must cut it short.
	if elapsed > 200*time.Millisecond {
		t.Errorf("elapsed = %v, want the budget to stop the chain early", elapsed)
	}
	if len(failures) == 0 || len(failures) == 5 {
		t.Errorf("failures = %d, want a partial chain", len(failures))
	}
}

// A cancelled caller is exit code 6, an exhausted budget is an upstream
// failure — the CLI branches on the difference, so they must not collapse.
func TestAutoSearchDistinguishesCancellationFromBudget(t *testing.T) {
	t.Parallel()
	ctx, cancel := context.WithCancel(context.Background())
	cancel()

	auto := newTestAuto(time.Second, namedSearcher{name: "one", searcher: &fakeSearcher{results: nil}})
	_, _, _, err := auto.SearchSelect(ctx, "q", 5)
	if err == nil {
		t.Fatal("expected an error for a cancelled context")
	}
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("error = %v, want it to wrap context.Canceled", err)
	}
	if strings.Contains(err.Error(), "budget") {
		t.Errorf("error = %q, want cancellation reported as cancellation", err)
	}
}

// NewFromConfig is the single constructor the CLI and MCP both go through, so
// the chain has to arrive as a plain Searcher and be recognisable as one that
// can report which provider served.
func TestNewFromConfigBuildsAutoChain(t *testing.T) {
	t.Parallel()
	cfg := config.Defaults()

	searcher, err := NewFromConfig(&cfg, AutoBackend)
	if err != nil {
		t.Fatal(err)
	}
	auto, ok := searcher.(*Auto)
	if !ok {
		t.Fatalf("searcher = %T, want *Auto", searcher)
	}
	if _, ok := searcher.(SelectingSearcher); !ok {
		t.Fatal("*Auto must implement SelectingSearcher so callers can report the serving provider")
	}
	if got := auto.Names(); !reflect.DeepEqual(got, AutoChainNames(&cfg)) {
		t.Fatalf("Names() = %v, want the resolved chain %v", got, AutoChainNames(&cfg))
	}
}

// Nesting a chain inside a fan-out would hide which provider answered and
// double up on backends the caller already listed.
func TestAutoIsNotAFederationMember(t *testing.T) {
	t.Parallel()
	cfg := config.Defaults()

	if _, err := NewMultiFromConfig(&cfg, []string{AutoBackend, "ddg"}); err == nil {
		t.Fatal("expected --multi to reject auto")
	}
	if _, err := NewRandomFromConfig(&cfg, []string{AutoBackend}); err == nil {
		t.Fatal("expected --random to reject auto")
	}
	// "all" resolves from the provider registry, which auto is not part of.
	for _, name := range AvailableBackends() {
		if name == AutoBackend {
			t.Fatal("auto leaked into AvailableBackends, so --multi=all would nest chains")
		}
	}
}

func TestSelectableBackendsLeadsWithAuto(t *testing.T) {
	t.Parallel()
	got := SelectableBackends()
	if len(got) != len(AvailableBackends())+1 || got[0] != AutoBackend {
		t.Fatalf("SelectableBackends() = %v, want auto followed by every provider", got)
	}
	if !IsBackend(AutoBackend) || !IsBackend("ddg") || IsBackend("nope") {
		t.Fatal("IsBackend must accept auto and every provider, and nothing else")
	}
}
