package search

import (
	"testing"

	config "github.com/1broseidon/ketch/internal/configbase"
)

func TestNewFromConfigBuildsRetainedKeyPools(t *testing.T) {
	cfg := config.Defaults()
	cfg.SetProvider("firecrawl_api_key", "firecrawl-legacy")
	cfg.SetProvider("firecrawl_api_keys", []string{"firecrawl-new"})
	cfg.SetProvider("keenable_api_key", "keenable-legacy")
	cfg.SetProvider("keenable_api_keys", []string{"keenable-new"})
	cfg.SetProvider("parallel_api_key", "parallel-legacy")
	cfg.SetProvider("parallel_api_keys", []string{"parallel-new"})

	for _, backend := range []string{"firecrawl", "keenable", "parallel"} {
		searcher, err := NewFromConfig(&cfg, backend)
		if err != nil {
			t.Fatalf("%s: %v", backend, err)
		}
		var size int
		switch candidate := searcher.(type) {
		case *Firecrawl:
			size = candidate.keys.size()
		case *Keenable:
			size = candidate.keys.size()
		case *Parallel:
			size = candidate.keys.size()
		default:
			t.Fatalf("%s: unexpected searcher %T", backend, searcher)
		}
		if size != 2 {
			t.Errorf("%s pool size = %d, want 2", backend, size)
		}
	}
}

func TestExportedBackendConstructorsKeepSingleKeyCompatibility(t *testing.T) {
	keenableKey := "keenable"
	tests := []struct {
		name string
		size int
	}{
		{name: "firecrawl", size: NewFirecrawl("firecrawl").keys.size()},
		{name: "keenable", size: NewKeenable(&keenableKey).keys.size()},
		{name: "parallel", size: NewParallel().keys.size()},
	}
	for _, tc := range tests {
		want := 1
		if tc.name == "parallel" {
			want = 0
		}
		if tc.size != want {
			t.Errorf("%s constructor pool size = %d, want %d", tc.name, tc.size, want)
		}
	}
}

func TestNewFromConfigParallelIsKeyless(t *testing.T) {
	cfg := config.Defaults()
	searcher, err := NewFromConfig(&cfg, "parallel")
	if err != nil {
		t.Fatal(err)
	}
	backend, ok := searcher.(*Parallel)
	if !ok {
		t.Fatalf("unexpected type %T", searcher)
	}
	if backend.endpoint != parallelEndpoint {
		t.Fatalf("endpoint = %q, want %q", backend.endpoint, parallelEndpoint)
	}
}

func TestNewFromConfigFirecrawlURL(t *testing.T) {
	t.Run("hosted allows empty key", func(t *testing.T) {
		cfg := config.Defaults()
		searcher, err := NewFromConfig(&cfg, "firecrawl")
		if err != nil {
			t.Fatal(err)
		}
		backend := searcher.(*Firecrawl)
		if backend.keys.size() != 0 {
			t.Fatalf("keys = %d, want 0", backend.keys.size())
		}
		if got := backend.endpoint; got != config.FirecrawlSearchURL(config.DefaultFirecrawlURL) {
			t.Fatalf("endpoint = %q, want hosted /v2/search", got)
		}
	})

	t.Run("self-hosted allows empty key", func(t *testing.T) {
		cfg := config.Defaults()
		cfg.SetProvider("firecrawl_url", "http://localhost:3002")
		searcher, err := NewFromConfig(&cfg, "firecrawl")
		if err != nil {
			t.Fatal(err)
		}
		backend := searcher.(*Firecrawl)
		if got := backend.endpoint; got != "http://localhost:3002/v2/search" {
			t.Fatalf("endpoint = %q, want local /v2/search", got)
		}
	})

	t.Run("custom base with key", func(t *testing.T) {
		cfg := config.Defaults()
		cfg.SetProvider("firecrawl_url", "https://fc.example.com/")
		cfg.SetProvider("firecrawl_api_key", "k")
		searcher, err := NewFromConfig(&cfg, "firecrawl")
		if err != nil {
			t.Fatal(err)
		}
		backend := searcher.(*Firecrawl)
		if got := backend.endpoint; got != "https://fc.example.com/v2/search" {
			t.Fatalf("endpoint = %q", got)
		}
	})
}
