package search

import (
	"context"
	"fmt"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/1broseidon/ketch/health"
	"github.com/1broseidon/ketch/httpx"
	config "github.com/1broseidon/ketch/internal/configbase"
	"github.com/PuerkitoBio/goquery"
)

// DDG searches DuckDuckGo's HTML interface.
type DDG struct {
	client *http.Client
}

// NewDDG creates a new DuckDuckGo search backend.
func NewDDG() *DDG {
	return &DDG{client: httpx.Default()}
}

// Search queries DuckDuckGo and returns up to limit results.
func (d *DDG) Search(ctx context.Context, query string, limit int) ([]Result, error) {
	resp, err := d.fetchResults(ctx, query)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	doc, err := goquery.NewDocumentFromReader(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to parse ddg response: %w", err)
	}

	var results []Result
	doc.Find(".result").Each(func(i int, s *goquery.Selection) {
		if len(results) >= limit {
			return
		}

		title := strings.TrimSpace(s.Find(".result__title .result__a").Text())
		href, _ := s.Find(".result__title .result__a").Attr("href")
		snippet := strings.TrimSpace(s.Find(".result__snippet").Text())

		if title == "" || href == "" {
			return
		}

		// DDG wraps URLs in a redirect; extract the actual URL
		parsed := extractDDGURL(href)

		results = append(results, Result{
			Title:       title,
			URL:         parsed,
			Description: snippet,
		})
	})

	return results, nil
}

func (d *DDG) fetchResults(ctx context.Context, query string) (*http.Response, error) {
	u := fmt.Sprintf("https://html.duckduckgo.com/html/?q=%s", url.QueryEscape(query))
	for range 3 {
		req, err := http.NewRequestWithContext(ctx, "GET", u, nil)
		if err != nil {
			return nil, err
		}
		// DuckDuckGo's HTML endpoint answers a non-browser UA with a
		// challenge page; the process User-Agent (a desktop Chrome by
		// default) is what it accepts, and the transport adds the rest of a
		// browser's headers beside it.
		req.Header.Set("User-Agent", httpx.UserAgent())
		req.Header.Set("Accept", httpx.DocumentAccept)

		resp, err := d.client.Do(req)
		if err != nil {
			return nil, fmt.Errorf("ddg request failed: %w", err)
		}
		if resp.StatusCode == http.StatusOK {
			return resp, nil
		}
		resp.Body.Close()
		if resp.StatusCode != http.StatusAccepted {
			return nil, fmt.Errorf("ddg returned status %d", resp.StatusCode)
		}
		time.Sleep(500 * time.Millisecond)
	}
	return nil, fmt.Errorf("ddg rate limited after retries")
}

func extractDDGURL(href string) string {
	u, err := url.Parse(href)
	if err != nil {
		return href
	}
	if uddg := u.Query().Get("uddg"); uddg != "" {
		return uddg
	}
	return href
}

// ProbeDDG checks the provider using a caller-supplied client and endpoint.
func ProbeDDG(ctx context.Context, client *http.Client, endpoint string) (health.Status, string) {
	resp, err := health.Get(ctx, client, endpoint+"?q=test", map[string]string{"User-Agent": httpx.UserAgent()})
	if err != nil {
		return health.StatusUnreachable, health.ErrorDetail(err)
	}
	defer health.Drain(resp)

	switch resp.StatusCode {
	case http.StatusOK:
		return health.StatusOK, ""
	case http.StatusAccepted:
		return health.StatusOK, "reachable (rate limited)"
	default:
		return health.StatusUnreachable, fmt.Sprintf("returned status %d", resp.StatusCode)
	}
}

func ddgProvider() Provider {
	return Provider{
		Settings: []config.Setting{},
		AutoRank: 120,
		ID:       "ddg",
		Name:     "DuckDuckGo",
		Usable:   func(*config.Config) bool { return true },
		New:      func(c *config.Config) (Searcher, error) { return NewDDG(), nil },
		Probe: func(ctx context.Context, client *http.Client, c *config.Config) (health.Status, string) {
			return ProbeDDG(ctx, client, "https://html.duckduckgo.com/html/")
		},
	}
}
