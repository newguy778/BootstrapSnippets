package search_test

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"strings"
	"testing"

	"github.com/1broseidon/ketch/config"
	"github.com/1broseidon/ketch/httpx"
	"github.com/1broseidon/ketch/search"
)

type providerFixtureTransport struct {
	t *testing.T
}

func (f providerFixtureTransport) RoundTrip(r *http.Request) (*http.Response, error) {
	if r.Method != http.MethodPost || r.URL.Scheme+"://"+r.URL.Host+r.URL.Path != "https://api.firecrawl.dev/v2/search" {
		f.t.Error("registry factory selected the wrong method or endpoint")
	}
	if r.Header.Get("Authorization") != "Bearer registry-key" {
		f.t.Error("registry settings did not reach the authorization header")
	}
	var body map[string]any
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil || body["query"] != "registry query" {
		f.t.Error("registry factory did not preserve the query")
	}
	if _, exists := body["integration"]; exists {
		f.t.Error("firecrawl request included an integration tracking tag")
	}
	payload := `{"success":true,"data":{"web":[{"title":"Fixture","url":"https://example.com/result","description":"Result text"}]}}`
	return &http.Response{StatusCode: http.StatusOK, Header: make(http.Header), Body: io.NopCloser(strings.NewReader(payload))}, nil
}

func TestRegistryRetainedKeyedProviderThroughHTTP(t *testing.T) {
	client := httpx.Default()
	previous := client.Transport
	defer func() { client.Transport = previous }()

	cfg := config.Defaults()
	cfg.SetProvider("firecrawl_api_keys", []string{"registry-key"})
	client.Transport = providerFixtureTransport{t: t}
	backend, err := search.NewFromConfig(&cfg, "firecrawl")
	if err != nil {
		t.Fatal(err)
	}
	results, err := backend.Search(context.Background(), "registry query", 1)
	if err != nil {
		t.Fatal(err)
	}
	if len(results) != 1 || results[0].URL != "https://example.com/result" || results[0].Description != "Result text" {
		t.Fatalf("registry result mapping changed: %+v", results)
	}
}
