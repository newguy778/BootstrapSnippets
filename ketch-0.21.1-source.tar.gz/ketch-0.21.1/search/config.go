package search

import (
	"fmt"
	"net/http"
	"strings"

	"github.com/1broseidon/ketch/internal/failure"

	"github.com/1broseidon/ketch/httpx"
	config "github.com/1broseidon/ketch/internal/configbase"
)

// ErrUnknownBackend identifies an unknown provider; missing prerequisites do not wrap it.
var ErrUnknownBackend = failure.New(failure.Validation, "unknown_backend", "unknown search backend")

// instanceClient returns base with the operator's http_headers applied.
// Firecrawl uses it for searches and doctor probes; headers reach only its
// configured origin.
func instanceClient(base *http.Client, c *config.Config) (*http.Client, error) {
	client, err := httpx.WithOriginHeaders(base, c.HTTPHeaders)
	if err != nil {
		return nil, fmt.Errorf("http_headers: %w", err)
	}
	return client, nil
}

// instanceRedactor returns the sanitiser for errors from a self-hosted
// instance: it removes every configured http_headers value, which the instance
// (or an origin it redirects to) may echo back in a body, a header or a
// redirect. Every error a search returns and every doctor detail from these
// providers passes through it.
func instanceRedactor(c *config.Config) *httpx.Redactor {
	return httpx.NewRedactor(c.HTTPHeaders)
}

// NewFromConfig constructs a registered search provider or the auto fallback chain.
func NewFromConfig(cfg *config.Config, backend string) (Searcher, error) {
	if backend == AutoBackend {
		return NewAutoFromConfig(cfg)
	}
	p, ok := Lookup(backend)
	if !ok {
		return nil, fmt.Errorf("%w %q (available: %s)", ErrUnknownBackend, backend, strings.Join(SelectableBackends(), ", "))
	}
	c := *cfg
	return p.Build(&c)
}

// SelectableBackends returns every value accepted by --backend and the backend
// config key: the auto chain first, then the providers in registry order.
func SelectableBackends() []string {
	return append([]string{AutoBackend}, AvailableBackends()...)
}

// IsBackend reports whether id names a selectable backend.
func IsBackend(id string) bool {
	if id == AutoBackend {
		return true
	}
	_, ok := Lookup(id)
	return ok
}
