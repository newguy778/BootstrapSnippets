package search

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
)

func TestFeatureDDGSearchParses(t *testing.T) {
	t.Parallel()
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html")
		fmt.Fprint(w, `<html><body>
			<div class="result">
				<h2 class="result__title"><a class="result__a" href="https://golang.org/">Go Language</a></h2>
				<div class="result__snippet">The Go programming language</div>
			</div>
			<div class="result">
				<h2 class="result__title"><a class="result__a" href="https://go.dev/">Go Dev</a></h2>
				<div class="result__snippet">Go developer portal</div>
			</div>
		</body></html>`)
	}))
	defer server.Close()

	d := &DDG{client: &http.Client{Transport: &rewriteTransport{base: http.DefaultTransport, target: server.URL}}}
	results, err := d.Search(context.Background(), "golang", 10)
	if err != nil {
		t.Fatalf("Search error: %v", err)
	}
	if len(results) != 2 {
		t.Fatalf("got %d results, want 2", len(results))
	}
	if results[0].Title != "Go Language" {
		t.Errorf("title = %q, want %q", results[0].Title, "Go Language")
	}
}

func TestFeatureDDGRetryOn202(t *testing.T) {
	t.Parallel()
	var attempts atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		n := attempts.Add(1)
		if n < 3 {
			w.WriteHeader(http.StatusAccepted)
			return
		}
		w.Header().Set("Content-Type", "text/html")
		fmt.Fprint(w, `<html><body>
			<div class="result">
				<h2 class="result__title"><a class="result__a" href="https://example.com">Example</a></h2>
				<div class="result__snippet">After retries</div>
			</div>
		</body></html>`)
	}))
	defer server.Close()

	d := &DDG{client: &http.Client{Transport: &rewriteTransport{base: http.DefaultTransport, target: server.URL}}}
	results, err := d.Search(context.Background(), "test", 5)
	if err != nil {
		t.Fatalf("Search error after retries: %v", err)
	}
	if len(results) != 1 {
		t.Fatalf("got %d results, want 1", len(results))
	}
	if attempts.Load() < 3 {
		t.Errorf("expected at least 3 attempts, got %d", attempts.Load())
	}
}

func TestFeatureDDGLimitRespected(t *testing.T) {
	t.Parallel()
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html")
		fmt.Fprint(w, `<html><body>
			<div class="result"><h2 class="result__title"><a class="result__a" href="https://a.com">A</a></h2><div class="result__snippet">a</div></div>
			<div class="result"><h2 class="result__title"><a class="result__a" href="https://b.com">B</a></h2><div class="result__snippet">b</div></div>
			<div class="result"><h2 class="result__title"><a class="result__a" href="https://c.com">C</a></h2><div class="result__snippet">c</div></div>
		</body></html>`)
	}))
	defer server.Close()

	d := &DDG{client: &http.Client{Transport: &rewriteTransport{base: http.DefaultTransport, target: server.URL}}}
	results, err := d.Search(context.Background(), "test", 1)
	if err != nil {
		t.Fatal(err)
	}
	if len(results) != 1 {
		t.Errorf("got %d results, want 1 (limit)", len(results))
	}
}

func TestFeatureFirecrawlSearchParses(t *testing.T) {
	t.Parallel()
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") == "" {
			http.Error(w, "unauthorized", http.StatusUnauthorized)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		fmt.Fprint(w, `{"success":true,"data":{"web":[
			{"url":"https://go.dev/blog/error-handling-and-go","title":"Error handling and Go","description":"Go code uses error values."},
			{"url":"https://go.dev/doc/","title":"Go Docs","description":"Go documentation"}
		]}}`)
	}))
	defer server.Close()

	f := &Firecrawl{keys: newKeyPool([]string{"k"}), client: &http.Client{Transport: &rewriteTransport{base: http.DefaultTransport, target: server.URL}}}
	results, err := f.Search(context.Background(), "golang error handling", 5)
	if err != nil {
		t.Fatalf("Search returned error: %v", err)
	}
	if len(results) != 2 {
		t.Fatalf("got %d results, want 2", len(results))
	}
	if results[0].Title != "Error handling and Go" {
		t.Errorf("title = %q, want %q", results[0].Title, "Error handling and Go")
	}
	if results[0].URL != "https://go.dev/blog/error-handling-and-go" {
		t.Errorf("url = %q, want blog URL", results[0].URL)
	}
	if results[0].Description != "Go code uses error values." {
		t.Errorf("description = %q, want snippet", results[0].Description)
	}
}

func TestFeatureFirecrawlRequestShape(t *testing.T) {
	t.Parallel()
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if got := r.Method; got != http.MethodPost {
			t.Errorf("method = %q, want POST", got)
		}
		if got := r.Header.Get("Authorization"); got != "Bearer test-key" {
			t.Errorf("Authorization = %q, want Bearer test-key", got)
		}
		var body map[string]any
		if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
			t.Fatalf("decode request body: %v", err)
		}
		if body["query"] != "rust release date" {
			t.Errorf("query = %q, want rust release date", body["query"])
		}
		if body["limit"] != float64(5) {
			t.Errorf("limit = %v, want 5", body["limit"])
		}
		w.Header().Set("Content-Type", "application/json")
		fmt.Fprint(w, `{"success":true,"data":{"web":[{"url":"https://www.rust-lang.org/","title":"Rust","description":"Rust"}]}}`)
	}))
	defer server.Close()

	f := &Firecrawl{keys: newKeyPool([]string{"test-key"}), client: &http.Client{Transport: &rewriteTransport{base: http.DefaultTransport, target: server.URL}}}
	_, err := f.Search(context.Background(), "rust release date", 5)
	if err != nil {
		t.Fatalf("Search error: %v", err)
	}
}

func TestFeatureFirecrawlHostedKeylessOmitsAuthorization(t *testing.T) {
	t.Parallel()
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if got := r.Header.Get("Authorization"); got != "" {
			t.Errorf("Authorization = %q, want empty for keyless hosted", got)
		}
		w.Header().Set("Content-Type", "application/json")
		fmt.Fprint(w, `{"success":true,"data":{"web":[{"url":"https://example.com","title":"Ex","description":"d"}]}}`)
	}))
	defer server.Close()

	f := &Firecrawl{keys: newKeyPool(nil), client: &http.Client{Transport: &rewriteTransport{base: http.DefaultTransport, target: server.URL}}}
	results, err := f.Search(context.Background(), "q", 1)
	if err != nil {
		t.Fatalf("Search error: %v", err)
	}
	if len(results) != 1 {
		t.Fatalf("got %d results, want 1", len(results))
	}
}

func TestFeatureFirecrawlSelfHostedEndpoint(t *testing.T) {
	t.Parallel()
	var gotPath string
	var gotAuth string
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotPath = r.URL.Path
		gotAuth = r.Header.Get("Authorization")
		w.Header().Set("Content-Type", "application/json")
		fmt.Fprint(w, `{"success":true,"data":{"web":[{"url":"https://example.com","title":"Ex","description":"d"}]}}`)
	}))
	defer server.Close()

	f := newFirecrawlWithKeys(nil, server.URL)
	results, err := f.Search(context.Background(), "q", 1)
	if err != nil {
		t.Fatalf("Search error: %v", err)
	}
	if len(results) != 1 {
		t.Fatalf("got %d results, want 1", len(results))
	}
	if gotPath != "/v2/search" {
		t.Errorf("path = %q, want /v2/search", gotPath)
	}
	if gotAuth != "" {
		t.Errorf("Authorization = %q, want empty for keyless self-host", gotAuth)
	}
}

func TestFeatureFirecrawlLimitRespected(t *testing.T) {
	t.Parallel()
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		fmt.Fprint(w, `{"success":true,"data":{"web":[
			{"url":"https://a.com","title":"A","description":"a"},
			{"url":"https://b.com","title":"B","description":"b"},
			{"url":"https://c.com","title":"C","description":"c"}
		]}}`)
	}))
	defer server.Close()

	f := &Firecrawl{keys: newKeyPool([]string{"k"}), client: &http.Client{Transport: &rewriteTransport{base: http.DefaultTransport, target: server.URL}}}
	results, err := f.Search(context.Background(), "test", 2)
	if err != nil {
		t.Fatal(err)
	}
	if len(results) != 2 {
		t.Errorf("got %d results, want 2 (limit)", len(results))
	}
}

func TestFeatureFirecrawlEmptyResults(t *testing.T) {
	t.Parallel()
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		fmt.Fprint(w, `{"success":true,"data":{"web":[]}}`)
	}))
	defer server.Close()

	f := &Firecrawl{keys: newKeyPool([]string{"k"}), client: &http.Client{Transport: &rewriteTransport{base: http.DefaultTransport, target: server.URL}}}
	results, err := f.Search(context.Background(), "nothing", 5)
	if err != nil {
		t.Fatal(err)
	}
	if len(results) != 0 {
		t.Errorf("expected empty results, got %d", len(results))
	}
}

func TestFeatureFirecrawlInvalidKey(t *testing.T) {
	t.Parallel()
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
	}))
	defer server.Close()

	f := &Firecrawl{keys: newKeyPool([]string{"bad-key"}), client: &http.Client{Transport: &rewriteTransport{base: http.DefaultTransport, target: server.URL}}}
	_, err := f.Search(context.Background(), "test", 5)
	if err == nil {
		t.Fatal("expected error for 401 response")
	}
	if !strings.Contains(err.Error(), "firecrawl_api_key") {
		t.Errorf("error %q should carry the config hint", err.Error())
	}
}

func TestFeatureFirecrawlServerError(t *testing.T) {
	t.Parallel()
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		http.Error(w, "internal error", http.StatusInternalServerError)
	}))
	defer server.Close()

	f := &Firecrawl{keys: newKeyPool([]string{"k"}), client: &http.Client{Transport: &rewriteTransport{base: http.DefaultTransport, target: server.URL}}}
	_, err := f.Search(context.Background(), "test", 5)
	if err == nil {
		t.Fatal("expected error for 500 response")
	}
}

func TestFeatureKeenableSearchParses(t *testing.T) {
	t.Parallel()
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		fmt.Fprint(w, `{
			"results": [
				{"title": "Go Docs", "url": "https://go.dev/doc/", "description": "", "snippet": "Go documentation"},
				{"title": "Go Blog", "url": "https://go.dev/blog/", "description": "The Go Blog"}
			]
		}`)
	}))
	defer server.Close()

	k := &Keenable{client: &http.Client{Transport: &rewriteTransport{base: http.DefaultTransport, target: server.URL}}}
	results, err := k.Search(context.Background(), "golang", 5)
	if err != nil {
		t.Fatalf("Search error: %v", err)
	}
	if len(results) != 2 {
		t.Fatalf("got %d results, want 2", len(results))
	}
	if results[0].Title != "Go Docs" {
		t.Errorf("title = %q, want %q", results[0].Title, "Go Docs")
	}
	if results[0].URL != "https://go.dev/doc/" {
		t.Errorf("url = %q, want %q", results[0].URL, "https://go.dev/doc/")
	}
	if results[0].Description != "Go documentation" {
		t.Errorf("description = %q, want %q", results[0].Description, "Go documentation")
	}
	// The second result carries only a meta description, which is the fallback.
	if results[1].Description != "The Go Blog" {
		t.Errorf("description = %q, want %q", results[1].Description, "The Go Blog")
	}
}

func TestFeatureKeenableSnippetIsCollapsedAndCapped(t *testing.T) {
	t.Parallel()
	long := strings.Repeat("word ", 400)
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		fmt.Fprintf(w, `{
			"results": [
				{"title": "Wrapped", "url": "https://go.dev/a", "description": "", "snippet": "line one\n\nline two"},
				{"title": "Long", "url": "https://go.dev/b", "description": "", "snippet": %q}
			]
		}`, long)
	}))
	defer server.Close()

	k := &Keenable{client: &http.Client{Transport: &rewriteTransport{base: http.DefaultTransport, target: server.URL}}}
	results, err := k.Search(context.Background(), "golang", 5)
	if err != nil {
		t.Fatalf("Search error: %v", err)
	}
	if results[0].Description != "line one line two" {
		t.Errorf("description = %q, want %q", results[0].Description, "line one line two")
	}
	if got := len([]rune(results[1].Description)); got != keenableSnippetMaxChars {
		t.Errorf("description length = %d, want %d", got, keenableSnippetMaxChars)
	}
}

func TestFeatureKeenableKeylessRequestShape(t *testing.T) {
	t.Parallel()
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if got := r.Method; got != "POST" {
			t.Errorf("method = %q, want POST", got)
		}
		// No key configured => keyless public endpoint, no X-API-Key.
		if got := r.URL.Path; got != "/v1/search/public" {
			t.Errorf("path = %q, want /v1/search/public", got)
		}
		if got := r.Header.Get("X-API-Key"); got != "" {
			t.Errorf("X-API-Key = %q, want empty for keyless", got)
		}
		if got := r.Header.Get("X-Keenable-Title"); got != keenableAppTitle {
			t.Errorf("X-Keenable-Title = %q, want the identifier the public endpoint requires (%q)", got, keenableAppTitle)
		}
		if got := r.Header.Get("User-Agent"); strings.Contains(strings.ToLower(got), "ketch") {
			t.Errorf("User-Agent = %q, want no ketch attribution tag", got)
		}
		var body map[string]any
		if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
			t.Fatalf("decode request body: %v", err)
		}
		if body["query"] != "test query" {
			t.Errorf("query = %q, want test query", body["query"])
		}
		if body["mode"] != "pro" {
			t.Errorf("mode = %q, want pro", body["mode"])
		}
		w.Header().Set("Content-Type", "application/json")
		fmt.Fprint(w, `{"results":[{"title":"A","url":"https://a.com","description":"a"}]}`)
	}))
	defer server.Close()

	k := &Keenable{client: &http.Client{Transport: &rewriteTransport{base: http.DefaultTransport, target: server.URL}}}
	_, err := k.Search(context.Background(), "test query", 5)
	if err != nil {
		t.Fatalf("Search error: %v", err)
	}
}

func TestFeatureKeenableKeyedRequestShape(t *testing.T) {
	t.Parallel()
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// A configured key switches to the authenticated endpoint + X-API-Key.
		if got := r.URL.Path; got != "/v1/search" {
			t.Errorf("path = %q, want /v1/search", got)
		}
		if got := r.Header.Get("X-API-Key"); got != "keen_test" {
			t.Errorf("X-API-Key = %q, want keen_test", got)
		}
		// The keyless app identifier belongs to the public endpoint only.
		if got := r.Header.Get("X-Keenable-Title"); got != "" {
			t.Errorf("X-Keenable-Title = %q, want empty on the authenticated endpoint", got)
		}
		w.Header().Set("Content-Type", "application/json")
		fmt.Fprint(w, `{"results":[{"title":"A","url":"https://a.com","description":"a"}]}`)
	}))
	defer server.Close()

	key := "keen_test"
	k := &Keenable{keys: newKeyPool([]string{key}), client: &http.Client{Transport: &rewriteTransport{base: http.DefaultTransport, target: server.URL}}}
	_, err := k.Search(context.Background(), "test", 5)
	if err != nil {
		t.Fatalf("Search error: %v", err)
	}
}

func TestFeatureKeenableLimitRespected(t *testing.T) {
	t.Parallel()
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		fmt.Fprint(w, `{"results":[
			{"title":"A","url":"https://a.com","description":"a"},
			{"title":"B","url":"https://b.com","description":"b"},
			{"title":"C","url":"https://c.com","description":"c"}
		]}`)
	}))
	defer server.Close()

	k := &Keenable{client: &http.Client{Transport: &rewriteTransport{base: http.DefaultTransport, target: server.URL}}}
	results, err := k.Search(context.Background(), "test", 2)
	if err != nil {
		t.Fatal(err)
	}
	if len(results) != 2 {
		t.Errorf("got %d results, want 2 (limit)", len(results))
	}
}

func TestFeatureKeenableEmptyResults(t *testing.T) {
	t.Parallel()
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		fmt.Fprint(w, `{"results": []}`)
	}))
	defer server.Close()

	k := &Keenable{client: &http.Client{Transport: &rewriteTransport{base: http.DefaultTransport, target: server.URL}}}
	results, err := k.Search(context.Background(), "nothing", 5)
	if err != nil {
		t.Fatal(err)
	}
	if len(results) != 0 {
		t.Errorf("expected empty results, got %d", len(results))
	}
}

func TestFeatureKeenable401(t *testing.T) {
	t.Parallel()
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
	}))
	defer server.Close()

	key := "bad-key"
	k := &Keenable{keys: newKeyPool([]string{key}), client: &http.Client{Transport: &rewriteTransport{base: http.DefaultTransport, target: server.URL}}}
	_, err := k.Search(context.Background(), "test", 5)
	if err == nil {
		t.Fatal("expected error for 401 response")
	}
}

func TestFeatureKeenableServerError(t *testing.T) {
	t.Parallel()
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		http.Error(w, "internal error", http.StatusInternalServerError)
	}))
	defer server.Close()

	k := &Keenable{client: &http.Client{Transport: &rewriteTransport{base: http.DefaultTransport, target: server.URL}}}
	_, err := k.Search(context.Background(), "test", 5)
	if err == nil {
		t.Fatal("expected error for 500 response")
	}
}

// rewriteTransport rewrites request URLs to point to the test server.
type rewriteTransport struct {
	base   http.RoundTripper
	target string
}

func (t *rewriteTransport) RoundTrip(req *http.Request) (*http.Response, error) {
	// Rewrite the URL to point to our test server, preserving path and query
	req = req.Clone(req.Context())
	req.URL.Scheme = "http"
	req.URL.Host = t.target[len("http://"):]
	if t.base != nil {
		return t.base.RoundTrip(req)
	}
	return http.DefaultTransport.RoundTrip(req)
}
